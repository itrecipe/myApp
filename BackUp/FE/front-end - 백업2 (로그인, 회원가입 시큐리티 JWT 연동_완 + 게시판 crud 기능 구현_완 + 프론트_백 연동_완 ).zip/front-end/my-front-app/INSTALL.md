# LOGIN & BOARD PART

## 라이브러리 전체 설지 (router & axios)
npm install react-router-dom axios js-cookie sweetalert2 sweetalert2-react-content

### react router dom
npm install react-router-dom

### axios
npm install axios

### cookie
npm install js-cookie

### sweetalert2
npm install sweetalert2
npm install sweetalert2-react-content

----------------------------------------------
## 기본적으로 숙지하면 편한 명령

### 전체 라이브러리 설치
npm install

### vite 전역 설치 (루트 디렉토리에서 수행)
npm install -g create-vite

### vite로 리액트 프로젝트 생성 (예시)
create-vite project-name --template react

### cd 명령어로 프로젝트 내부로 진입하는법 (예시)
cd create-project


