package com.toy.backend.domain;

public class Boards {
}
