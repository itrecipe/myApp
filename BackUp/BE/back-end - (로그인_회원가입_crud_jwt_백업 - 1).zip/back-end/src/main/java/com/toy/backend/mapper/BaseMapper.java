package com.toy.backend.mapper;

//@Mapper // 해당 인터페이스가 Mybatis에서 SQL을 실행하는 Mapper라는 것을 알려주는 애너테이션
public interface BaseMapper {

}
