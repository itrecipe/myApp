package com.toy.backend.mapper;

//@Mapper
public interface BoardMapper {
}
