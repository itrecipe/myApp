package com.toy.backend.mapper;

public class FileMapper {
}
