import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import OLMap from "../../utils/OLMap";

interface MapState {
  map: OLMap | null;
}

const initialState: MapState = {
  map: null,
};

export const mapSlice = createSlice({
  name: "map",
  initialState,
  reducers: {
    setMap: (state, action: PayloadAction<OLMap>) => {
      state.map = action.payload;
    },
    clearMap: (state) => {
      state.map = null;
    },
  },
});

export const { setMap, clearMap } = mapSlice.actions;
export default mapSlice.reducer; // 리듀서 export
