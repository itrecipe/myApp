import styled from "styled-components";
import { FC, useRef, useEffect } from "react";
import "../../styles/OLMap.css"
import "ol/ol.css"
import OLMap from "../../utils/OLMap";
import { Tile } from "ol/layer";
import { XYZ } from "ol/source";
import {MapBrowserEvent} from "ol";
import {useMap} from "../../context/MapContext";

interface MapStylesProps {
  width? : string;
}

interface MapComponentProps {
  width? : string;
}

export const MapStyles = styled.div<MapStylesProps>`
  width: ${(props) => props.width || "100vw"};
  height: 100vh;
  overflow: hidden;
  display: flex;
  position:relative;
`;

const MapComponent: FC<MapComponentProps> = (props) => {
  const mapRef = useRef<HTMLDivElement>(null); // map container ref
  const {map, isInitialized} = useMap();

  useEffect(() => {
    if (isInitialized && map && mapRef.current) {
      map.setTarget(mapRef.current);
    }
  }, [isInitialized, map]);

  if(!isInitialized) {
    return <div></div>; // 초기화 전 로딩 표시
  }

  return <MapStyles ref={mapRef} width={props.width}></MapStyles>;
};

export default MapComponent;
