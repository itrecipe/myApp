

export const SmallSelectorStyle = {
        control: (provided: any) => ({
          ...provided,
          minHeight: "30px", // 높이 줄이기
          height: "30px",
            width : "100px",
          fontSize: "12px", // 글자 크기 줄이기
        }),
        valueContainer: (provided: any) => ({
          ...provided,
          padding: "0 8px", // 내부 여백 줄이기
        }),
        input: (provided: any) => ({
          ...provided,
          fontSize: "12px", // 입력 글자 크기
        }),
        singleValue: (provided: any) => ({
          ...provided,
          fontSize: "12px", // 선택된 값의 글자 크기
        }),
        placeholder: (provided: any) => ({
          ...provided,
          fontSize: "12px", // 플레이스홀더 글자 크기
        }),
        indicatorsContainer: (provided: any) => ({
          ...provided,
          height: "30px", // 인디케이터 영역 높이 줄이기
        }),
        dropdownIndicator: (provided: any) => ({
          ...provided,
          padding: "4px", // 드롭다운 인디케이터 크기 조정
        }),
        menu: (provided: any) => ({
          ...provided,
          fontSize: "12px", // 드롭다운 메뉴 글자 크기
            width: "100px"
        }),
        option: (provided: any, state: any) => ({
          ...provided,
          fontSize: "12px", // 드롭다운 옵션 글자 크기
          padding: "4px 8px", // 드롭다운 옵션 여백 줄이기
          /*backgroundColor: state.isSelected ? "#f0f0f0" : "white", // 선택된 옵션 스타일
          "&:hover": {
            backgroundColor: "#e6e6e6", // 마우스 오버 스타일
          },*/
        }),
      };