import styled from "styled-components";
import React, {FC, useEffect, useState} from "react";
import {NavResultItemContentStyles, NavResultItemStyles, NavResultItemTitleStyles} from "../../../styles/ListItemStyle";
import {useMap} from "../../../context/MapContext";
import {Feature} from "ol";
import {Point} from "ol/geom.js";


interface AddressResultItemProps {
  title? : string;
  road? : string;
  parcel? : string;
  zipCode? : string;
  x : number;
  y : number;
}


const AddressResultItemComponent: FC<AddressResultItemProps> = (props) => {
    const {map, isInitialized} = useMap();

    const onClick = () => {
        if(map) {
            console.log(props);

            const feature : Feature = map.createFeature("POINT(" + props.x + " " + props.y + ")", {
                attributes : props,
                isTransform : true
            });

            map.addFeature("AddressSearchLayer", feature);

            map.setCenter((feature.getGeometry() as Point).getCoordinates());
            map.setZoom(16);
        }
    }

    useEffect(() => {
    if (isInitialized && map) {
    }
  }, [isInitialized, map]);

    return <NavResultItemStyles onClick={onClick}>
        {props.title && (
            <NavResultItemTitleStyles>{props.title}</NavResultItemTitleStyles>
        )}
        {props.zipCode && (
            <NavResultItemContentStyles>우편번호 : {props.zipCode}</NavResultItemContentStyles>
        )}
        {props.road && (
            <NavResultItemContentStyles text_indent={"-38px"} padding_left={"38px"}>도로명 : {props.road}</NavResultItemContentStyles>
        )}
        {props.parcel && (
            <NavResultItemContentStyles>지번 : {props.parcel}</NavResultItemContentStyles>    
        )}
    </NavResultItemStyles>
}

export default AddressResultItemComponent