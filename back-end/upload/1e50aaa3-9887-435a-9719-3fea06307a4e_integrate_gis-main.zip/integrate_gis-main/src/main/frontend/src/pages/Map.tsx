import {MapContainer} from "../styles/MapStyle";
import MapComponent from "../components/map/MapComponent";
import NavComponent from "../components/map/NavComponent";
import {MapProvider} from "../context/MapContext";

const Map = () => {
    return (
      <MapProvider>
        <MapContainer>
            <NavComponent width={"300px"}/>
          <MapComponent width={"calc(100vw - 300px);"}/>
        </MapContainer>
      </MapProvider>
  );
}

export default Map;

/*
export default function Map() {

  return (
      <MapProvider>
        <MapContainer>
            <NavComponent width={"300px"}/>
          <MapComponent width={"calc(100vw - 300px);"}/>
        </MapContainer>
      </MapProvider>
  );
}*/
