import styled from "styled-components";
import React, {FC, useEffect, useState} from "react";
import Select, {ActionMeta} from "react-select";
import {SmallSelectorStyle} from  "../../../styles/SelectStyle";
import SampleAPI, {VworldAddressData, VworldAddressResponse} from "../../../api/SampleAPI";
import AddressResultItemComponent from "./AddressResultItemComponent";
import {useMap} from "../../../context/MapContext";
import {Icon, Style} from "ol/style.js";
import poi_icon from "../../../assets/images/map/poi_icon.png"
import {StyledInput} from "../../../styles/CommonStyle";


interface AddressSearchStylesProps {
  width? : string;
  height? : string;
}

interface AddressSearchComponentProps {
  width? : string;
  height? : string;
}


export const AddressSearchInputStyles = styled.div`
    width: 100%;
    display: flex;
`;

export const AddressSearchStyles = styled.div<AddressSearchStylesProps>`
  width: 100%;
  height: 100vh;
  padding: 10px 5px;
`;

export const AddressResultStyles = styled.div`
  width: 100%;
  height: calc(100% - 35px);
  overflow-y : auto;
`;

interface OptionType {
  value: string;
  label: string;
}

const AddressSearchComponent: FC<AddressSearchComponentProps> = (props) => {
    const {map, isInitialized} = useMap();
    const [keyword, setKeyword] = useState("");
    const [type, setType] = useState("road");
    const [resultList, setResultList] = useState([] as VworldAddressData[]);

    const typeOptions : OptionType[] = [
        {value : "road", label : "도로명" },
        {value : "parcel", label : "지번" }
    ];

    const onKeyDown = (e : React.KeyboardEvent<HTMLInputElement>) => {
        if(e.key === "Enter") {
            map.removeAllFeatures("AddressSearchLayer");
            setResultList([]);

            if(type === "road") {
                SampleAPI.vworldRoadAddressApi(keyword, 1000, 1, (result : VworldAddressResponse) => {
                    setResultList(result.LIST);
                })
            }else if(type === "parcel"){
                SampleAPI.vworldParcelAddressApi(keyword, 1000, 1, (result : VworldAddressResponse) => {
                    setResultList(result.LIST);
                })
            }
        }
    }

    useEffect(() => {
    if (isInitialized && map) {
      const iconStyle = new Style({
            image: new Icon({
                anchor: [0.5, 1],
                size : [400, 640],
                scale: 0.05,
                anchorXUnits: 'fraction',
                anchorYUnits: 'fraction',
                src: poi_icon
            })
        });

      map.setVectorLayer("AddressSearchLayer", {
         style : iconStyle,
         events :  {
             hover : (feature) => {
                 console.log(feature);
                 return feature.get("title") || feature.get("road");
             }
         }
      });


    }
  }, [isInitialized, map]);

    return <AddressSearchStyles width={props.width} height={props.height}>
        <AddressSearchInputStyles>
            <Select styles={SmallSelectorStyle} options={typeOptions} defaultValue={typeOptions[0]} onChange={(newValue) => setType(newValue.value)} />
            <StyledInput width={"calc(100% - 135px)"} placeholder={"주소입력"} onKeyDown={onKeyDown} onChange={(e) => setKeyword(e.target.value)} />
        </AddressSearchInputStyles>
        <AddressResultStyles>
            {resultList.map((item, index) => (
                <AddressResultItemComponent
                    title={item.address.bldnm}
                    road={item.address.road}
                    parcel={item.address.parcel}
                    zipCode={item.address.zipcode}
                    x={item.point.x}
                    y={item.point.y}
                />
            ))}
        </AddressResultStyles>
    </AddressSearchStyles>
}

export default AddressSearchComponent