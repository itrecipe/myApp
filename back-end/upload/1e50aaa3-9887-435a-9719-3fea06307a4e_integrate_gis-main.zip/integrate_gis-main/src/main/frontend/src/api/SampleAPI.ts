import APIUtils, {ApiResponse} from "../utils/APIUtils"

export type HelloResponse = {
    text : string,
    text2 : string
}

export type VworldAddressData = {
    address : {
        bldnm : string,
        bldnmdc : string,
        category : string,
        parcel : string,
        road : string,
        zipcode : string
    },
    id : string,
    point : {
        x : number,
        y : number
    }
}

export type VworldAddressResponse = {
    TotalPage : number,
    LIST : Array<VworldAddressData>
}

const SampleAPI = {
    hello : (response: (result : HelloResponse) => void) => {
        APIUtils.get({
            url : "api/sample/test",
            params : {
                test : 1,
                test2 : "aa"
            },
            response:(result : ApiResponse) => {
                const data : HelloResponse = result.DATA as HelloResponse;
                response(data);
            },
            error: (error) => {
                console.log("error");
                console.log(error);
            }
        });
    },
    vworldRoadAddressApi : (keyword : string, pageSize : number, page : number, response: (result : VworldAddressResponse) => void) => {
        APIUtils.post({
            url : "api/sample/vworldRoadAddressApi",
            params : {
                keyword : keyword,
                pageSize : pageSize,
                page : page
            },
            response:(result : ApiResponse) => {
                const data = result.DATA as VworldAddressResponse;
                response(data);
            },
            error: (error) => {
                console.log("error");
                console.log(error);
            }
        });
    },
    vworldParcelAddressApi : (keyword : string, pageSize : number, page : number, response: (result : VworldAddressResponse) => void) => {
        APIUtils.post({
            url : "api/sample/vworldParcelAddressApi",
            params : {
                keyword : keyword,
                pageSize : pageSize,
                page : page
            },
            response:(result : ApiResponse) => {
                const data = result.DATA as VworldAddressResponse;
                response(data);
            },
            error: (error) => {
                console.log("error");
                console.log(error);
            }
        });
    }
}


export default SampleAPI;
