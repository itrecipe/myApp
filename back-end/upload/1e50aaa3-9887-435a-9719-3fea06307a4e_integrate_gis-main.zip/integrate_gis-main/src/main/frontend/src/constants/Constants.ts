import Home from "../pages/Home";
import Map from "../pages/Map";
import Error from "../pages/Error";
import Auth from "../pages/Auth";

export const BASEURL = process.env.NODE_ENV === "production" ? "/" : "/api/";
export const VWORLD_KEY = process.env.NODE_ENV === "production" ? "24D169B1-4695-3D22-9904-FE0B0F1F1F17" : "24D169B1-4695-3D22-9904-FE0B0F1F1F17"
export const ROUTES = [
    {path: "/", component: Home, exact: true, name: "Home"},
    {path: "/auth", component: Auth, exact: false, name: "Auth"},
    {path: "/map", component: Map, exact: false, name: "Map"},
    {path: "/error", component: Error, exact: false, name: "Error"}
];