import APIUtils, {ApiResponse} from "../utils/APIUtils"

export type UserInfoResponse = {
    username : string,
    auth : string[]
}

const AuthAPI = {
    signIn : (username : string, password : string, callback : (result : UserInfoResponse) => void) => {
        APIUtils.post({
            isRequestBody: true,
            url : "auth/signIn",
            params : {
                username : username,
                password : password
            },
            response:(result : ApiResponse) => {
                console.log("response");
                console.log(result);
                /*axios.defaults.headers.common['Authorization'] = (result.DATA as String);*/
                callback.call(this, result.DATA);
            },
            error: (error) => {
                console.log("error");
                console.log(error);
            }
        });
    },
    signOut : (callback : (result : string) => void) => {
        APIUtils.post({
            isRequestBody: true,
            url : "auth/signOut",
            response:(result : ApiResponse) => {
                console.log("response");
                console.log(result);
                callback.call(this, result.RESULT);
            },
            error: (error) => {
                console.log("error");
                console.log(error);
                callback.call(this, error);
            }
        });
    },

    ping : (callback : (result : string) => void) => {
        APIUtils.get({
           url : window.location.pathname.substring(1, window.location.pathname.length),
           response : (result : ApiResponse) => {
               callback.call(this, result.RESULT);
           } ,
            error: (error) => {
               callback.call(this, error);
            }
        });
    }
}

export default AuthAPI;