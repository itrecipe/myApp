import View from 'ol/View'
import Map, { MapOptions } from 'ol/Map'
import {fromLonLat, transformExtent as olTransformExtent, transform as olTransform, getPointResolution} from "ol/proj.js";
import {WKT} from "ol/format.js";
import {ObjectEvent} from "ol/Object";
import {ImageTile, MapBrowserEvent} from "ol"
import {SelectEvent} from "ol/interaction/Select"
import {Draw, Modify, Snap} from "ol/interaction.js";
import {Circle, Geometry, LineString, Point, Polygon} from "ol/geom.js";
import {getLength} from "ol/sphere.js";
import {Vector as VectorLayer, VectorImage, Image as ImageLayer, Tile as TileLayer} from "ol/layer.js";
import {Vector as VectorSource, ImageWMS, TileWMS, ImageStatic} from "ol/source.js";
import {bbox} from "ol/loadingstrategy.js";
import {Circle as CircleStyle, Fill, Stroke, Style} from "ol/style.js";
import {getArea, getDistance} from 'ol/sphere';
import {Feature, Overlay} from "ol";
import {unByKey} from "ol/Observable.js";
import {Extent, getCenter as getOlCenter} from "ol/extent.js"
import {circular} from "ol/geom/Polygon.js";
import { METERS_PER_UNIT } from 'ol/proj/Units';
import {defaults as interactionDefaults, DragRotate, MouseWheelZoom, Select} from 'ol/interaction';
import {click, pointerMove} from 'ol/events/condition';
import {Options as VectorOptions} from "ol/layer/VectorImage";
import {Options as ImageWMSSourceOptions} from "ol/source/ImageWMS";
import {Options as TileWMSSourceOptions} from "ol/source/TileWMS";
import { Type } from 'ol/geom/Geometry';
import { DrawEvent } from 'ol/interaction/Draw';
import { StyleLike } from 'ol/style/Style.js';
import { FlatStyleLike } from 'ol/style/flat';
import { Coordinate } from 'ol/coordinate';
import BaseEvent from 'ol/events/Event';
import { FeatureLike } from 'ol/Feature';
import Image from "ol/Image";
import Tile from "ol/Tile";

export type BaseLayer = {
    name : string,
    layers : Array<any>
}

export type LayerInfo = {
    [key: string]: any
}

export type OLMapOptions = {
    target? : HTMLElement
    mapProj? : string,
    dataProj? : string,
    resolutions? : [],
    viewOptions? : {
        zoom? : number,
        minZoom? : number,
        maxZoom? : number,
        center? : Array<number>
    },
    baseLayers? : Array<BaseLayer>,
    drawHoverText? : string,
    controlOptions? : {
        isRotate? : boolean
    }
}

export type TransformOptions = {
	projection? : {
		source? : string,
		target? : string
	},
	geomType? : string,
	isTransform? : boolean
}

export type GeometryFormatOptions = TransformOptions & {
	outputType : string
}

export type VectorLayerOptions = {
	source? : VectorSource,
	style? : any,
	visible? : boolean,
	extent? : Extent,
	isTransform? : boolean,
	features? : Array<Feature>,
	events? : {
		select? : Function,
		unselect? : Function,
		hover? : Function,
		unhover? : Function
	},
	zIndex? : number
}

export type DrawData = {
	type : string,
	radius? : number,
	center : Coordinate,
	geom : string
}

export type DrawControlOptions = {
	style? : any,
	event? : Function,
	radius? : number,
	features? : Array<DrawData>
}

export type CreateFeatureOptions = TransformOptions & {
	labelGeom? : Geometry,
	attributes? : {[x: string]: any;},
	style? : StyleLike
}

export type SetWmsOptions = {
	url : string,
	params : WmsParams,
	opacity? : number,
	visible? : boolean,
	extent? : Extent,
	isSingleTile? : boolean,
	projection? : {
		source? : string,
		target? : string
	},
	method? : "GET" | "POST",
	event? : (event: BaseEvent) => unknown,
	zIndex? : number,
	isTransform? : boolean
}

export type WmsParams = {
	LAYERS? : string,
	STYLES? : string,
	VERSION? : string,
	SLD_BODY? : string,
	CSS_BODY? : string,
	tiled? : boolean,
	source? : ImageWMS | TileWMS,
	_t? : number
}

export type WmsOptions = {
	name : string,
	layerType : "WMS",
	extent? : Extent,
	opacity? : number,
	source? : ImageWMS | TileWMS,
	visible? : boolean,
}

export type SetImageOptions = {
	url : string,
	isTransform? : boolean,
	projection? : {
		source? : string,
		target? : string
	},
	extent? : Extent,
	size? : number,
	opacity? : number,
	event? : (event: BaseEvent) => unknown,
}

export type ImageSourceOptions = {
	url : string,
	crossOrigin : string,
	projection? : string,
	imageExtent : Extent,
	imageSize? : number
}

/*export type ImageLayerOptions = {
	name : string,
	layerType : "IMAGE",
	source :
}*/


class OLMap {

    static CODE = {
        EVENT: {
            MOVE_END: "moveEnd",
            MOVE_START: "moveStart",
            CLICK: "click",
            ZOOM_END: "zoomEnd",
            MOVE: "move",
            MOUSE_MOVE: "mouseMove",
            ROTATE: "rotate"
        },
        FEATURE_INFO_FORMAT: {
            JSON: "application/json",
            HTML: "text/html",
            JSONP: "text/javascript",
            GML2: "application/vnd.ogc.gml",
            GML3: "application/vnd.ogc.gml/3.1.1",
            TEXT: "text/plain"
        },
        DRAW_TYPE: {
            POINT: "point",
            LINE: "line",
            POLYGON: "polygon",
            CIRCLE: "circle",
            NONE: "none"
        },
        TOOLTIP_POSITION: {
            LEFT_TOP: "top-left",
            LEFT_MIDDLE: "center-left",
            LEFT_BOTTOM: "bottom-left",
            CENTER_TOP: "top-center",
            CENTER_MIDDLE: "center-center",
            CENTER_BOTTOM: "bottom-center",
            RIGHT_TOP: "top-right",
            RIGHT_MIDDLE: "center-right",
            RIGHT_BOTTOM: "bottom-right"
        },
        MEASURE_CONTROL: {
            NONE: "None",
            LENGTH: "LineString",
            AREA: "Polygon"
        }
    };

    #map : Map;
    #view : View;
    #element : HTMLElement;
    #mouseTooltipElement : HTMLElement;
	#measureTooltip : Overlay;
    #measureCnt = 0;
    #options : OLMapOptions;
    #wktFormat = new WKT();
    #layers = {
        base : {

        } as LayerInfo,
        vector : {

        } as LayerInfo,
        wms : {

        } as LayerInfo,
        image : {

        } as LayerInfo
    };
    #events = {
		moveEnd : {},
		moveStart : {},
		click : {},
		zoomEnd : {},
		move : {},
		mouseMove : {},
		rotate : {}
    };
    #vectorEvents = {};
    #baseLayerIndex:number;
    #interactions = {};
    #vectorSelectLayer = [];
	#measureStaticTooltipList=[];
	#isMeasureMode;
	#drawSelectFeature;
	#drawCallback : Function;

    #defaultStyle = new Style({
		fill : new Fill({
			color : 'rgba(255, 255, 255, 0.2)'
		}),
		stroke : new Stroke({
			color : '#ffcc33',
			width : 2
		}),
		image : new CircleStyle({
			radius : 7,
			fill : new Fill({
				color : '#ffcc33'
			})
		})
	});

	#measureStyle = new Style({
		fill: new Fill({
            color: 'rgba(255, 255, 255, 0.4)'
          }),
          stroke: new Stroke({
            color: '#0000FF',
            width: 3
          }),
          image: new CircleStyle({
            radius: 7,
            fill: new Fill({
              color: '#0000FF'
            })
          })
	});

	#drawingStyle = new Style({
		fill: new Fill({
			color: 'rgba(53, 187, 205, 0.2)'
		}),
		stroke: new Stroke({
			color: 'rgb(53, 187, 205)',
			lineDash: [10, 10],
			width: 3
		}),
		image: new CircleStyle({
			radius: 5,
			stroke: new Stroke({
				color: 'rgb(53, 187, 205)'
			}),
			fill: new Fill({
				color: 'rgba(255, 255, 255, 0.2)'
			})
		})
	});




    constructor(options : OLMapOptions) {
        this.#options = {
            target : options.target,
            mapProj : options.mapProj ?? "EPSG:3857",
            dataProj : options.dataProj ?? "EPSG:4326",
            resolutions : options.resolutions ?? null,
            drawHoverText : options.drawHoverText ?? "1. 도형을 삭제하고 싶으시면 도형 위에서 [Delete]키를 입력하세요. \n2. 도형의 점을 삭제하고 싶으신 경우 [ALT]키를 입력후 점을 클릭해주세요.\n\u00a0\u00a0\u00a0\u00a0※ 점/원은 불가, 선은 점이 2개, 면은 점이 3개가 초과한 경우만 가능함",
            viewOptions : {
                zoom : options.viewOptions?.zoom ?? 7,
                minZoom : options.viewOptions?.minZoom ?? 1,
                maxZoom : options.viewOptions?.maxZoom ?? 20,
                center : options.viewOptions?.center ?? [127.7528832672847, 36.23307548960749]
            },
            controlOptions : {
                isRotate : options.controlOptions?.isRotate ?? false
            }
        }

        const layerList = [];

        if(options.baseLayers !== undefined) {
            for(let i = 0, cnt = options.baseLayers.length; i<cnt; i++) {
                const baseLayer = options.baseLayers[i];
                this.#layers.base[baseLayer.name] = {
                    layers : []
                }

                for(let j = 0, cnt2 = baseLayer.layers.length; j < cnt2; j++) {
                    const layer = baseLayer.layers[j];
                    this.#layers.base[baseLayer.name].layers.push(layer);
                    layerList.push(layer);
                }
            }
        }

        this.#baseLayerIndex = layerList.length;

        const viewOption = {
            center : fromLonLat(this.#options.viewOptions.center),
            zoom : this.#options.viewOptions.zoom,
            projection : this.#options.mapProj,
            minZoom : this.#options.viewOptions.minZoom,
            maxZoom : this.#options.viewOptions.maxZoom
        }

        this.#view = new View(viewOption);

        const mapOption : MapOptions = {
            layers : layerList,
            interactions : this.#setInteractions(),
            view : this.#view
        };

        this.#map = new Map(mapOption);

		if(this.#options.target) {
			this.setTarget(this.#options.target);
		}

        this.#view.on("change:center", this.#moveEndListener.bind(this));
        this.#map.on("click", this.#mapClickListener.bind(this));
		this.#map.on("pointermove", this.#mouseMoveListener.bind(this));

		this.setVectorLayer("measureControl", {
			style : this.#measureStyle,
			zIndex : 99999999
		});
    }

	setTarget(target : HTMLElement) {
		this.#options.target = target;
		this.#map.setTarget(this.#options.target);
        this.#element = this.#map.getTargetElement();
		this.#mouseTooltipElement = document.createElement("div");
		this.#mouseTooltipElement.style.position = "absolute";
		this.#mouseTooltipElement.style.display = "none";
		this.#mouseTooltipElement.className = "OLMap_TooltipBox";

		this.#element.appendChild(this.#mouseTooltipElement);
	};

    #eventCall(type : string, args1? : any, args2? : any) {
		for(const key in this.#events[type]) {
			const evt = this.#events[type][key];
			evt.call(this, args1, args2);
		}
    };


    #moveEndListener(e : ObjectEvent) {
        const center = this.getCenter(true);
        this.#eventCall(OLMap.CODE.EVENT.MOVE_END, e, center);
    };

    #mapClickListener(e : MapBrowserEvent<any>) {
		this.#eventCall(OLMap.CODE.EVENT.CLICK, e);

		/*if(this.#isMeasureMode === OLMap.CODE.MEASURE_CONTROL.LENGTH) {
			this.#measureCnt++;
            const el = this.#measureTooltip.getElement();
            el.className = 'OLTooltip OLTooltip-static sub';
            el.setAttribute("measurecnt", String(this.#measureCnt));
            const measureId = el.getAttribute("measureid");
            this.#measureTooltip.setOffset([0, -7]);
            this.#measureStaticTooltipList.push(el);
            this.#measureTooltip = this.createMeasureTooltip();

            this.#measureTooltip.getElement().setAttribute("measureid", measureId);
		}else{
			this.#eventCall(OLMap.CODE.EVENT.CLICK, e);
		}*/
	}

    #mouseMoveListener(e : MapBrowserEvent<any>) {
		let top = e.pixel[1];
		let left = e.pixel[0];
		let width = this.#mouseTooltipElement.offsetWidth;
		let height = this.#mouseTooltipElement.offsetHeight;
		let mapDivWidth = this.#element.offsetWidth;
		let mapDivHeight = this.#element.offsetHeight;

		if(top + 15 + height > mapDivHeight) {
			top = top - height - 15;
		}else{
			top += 15;
		}

		if(left + 15 + width > mapDivWidth) {
			left = left - width - 15;
		}else{
			left += 15;
		}

		this.#mouseTooltipElement.style.top = top+"px";
		this.#mouseTooltipElement.style.left = left+"px";

		if(e.dragging) {
			return;
		}

		const pixel = this.#map.getEventPixel(e.originalEvent);
		const hit = this.#map.hasFeatureAtPixel(pixel);

		if(hit) {
			this.#map.forEachFeatureAtPixel(e.pixel, (feature, layer) => {
				if(feature) {
					if(layer) {
						const layerName = layer.get("name");
						if(this.#vectorEvents[layerName] && this.#vectorEvents[layerName].select) {
							this.#map.getTargetElement().style.cursor = 'pointer';
							return false;
						}
					}
				}
			});
		}else{
			this.#map.getTargetElement().style.cursor = '';
		}
	}

    #setInteractions() {
		const defaultsInteractions = interactionDefaults({
			altShiftDragRotate : false,
//			dragPan: false,
			pinchRotate:false,
			mouseWheelZoom: false,
			doubleClickZoom: false
		});
		const addInteractionArr = [];

		addInteractionArr.push(new MouseWheelZoom({
			constrainResolution : true
			,duration: 0
//			,useAnchor: false
		}));

		this.#interactions["vectorClickEvent"] = new Select({
			condition : click,
			style : (feature, resolution) => {
				/*const layerName = feature.layerName;*/
                const layerName = feature.get("layerName");
				const lyr = this.#layers.vector[layerName];

				const styles = lyr.getStyle();

				let style = null;

				if(typeof styles == "function") {
					style = styles.call(this, feature, resolution, "click");
				}else if(styles != null && styles.length) {
					style = styles[0];
				}else if(styles != null && !styles.length) {
					style = styles;
				}

				return style;
			},
			layers : this.#vectorSelectLayer
		});

		addInteractionArr.push(this.#interactions["vectorClickEvent"]);

		this.#interactions["vectorClickEvent"].on("select", (e : SelectEvent) => {
			const selectFeatures = e.selected;
			const unSelectFeatures = e.deselected;

			for(const i in unSelectFeatures) {
				const feature = unSelectFeatures[i];
				/*const layerName = feature.layerName;*/
                const layerName = feature.get("layerName");
				if(this.#vectorEvents[layerName] && this.#vectorEvents[layerName]["unselect"]) {
					this.#vectorEvents[layerName]["unselect"].call(this, feature);
				}
			}

			for(const i in selectFeatures) {
				const feature = selectFeatures[i];
				/*const layerName = feature.layerName;*/
                const layerName = feature.get("layerName");
				if(this.#vectorEvents[layerName] && this.#vectorEvents[layerName]["select"]) {
					this.#vectorEvents[layerName]["select"].call(this, feature);
				}
			}

		});

		this.#interactions["vectorHoverEvent"] = new Select({
			condition : pointerMove,
			style : (feature, resolution) => {
				/*const layerName = feature.layerName;*/
                const layerName = feature.get("layerName");
				const lyr = this.#layers.vector[layerName];

				const styles = lyr.getStyle();

				let style = null;

				if(typeof styles == "function") {
					style = styles.call(this, feature, resolution, "hover");
				}else if(styles != null && styles.length) {
					style = styles[0];
				}else if(styles != null && !styles.length) {
					style = styles;
				}

				return style;
			},
			layers : this.#vectorSelectLayer
		});

		addInteractionArr.push(this.#interactions["vectorHoverEvent"]);

		this.#interactions["vectorHoverEvent"].on("select", (e : SelectEvent) => {
			const selectFeatures = e.selected;
			const unSelectFeatures = e.deselected;

			for(const i in unSelectFeatures) {
				const feature = unSelectFeatures[i];
				/*const layerName = feature.layerName;*/
                const layerName = feature.get("layerName");
				if(this.#vectorEvents[layerName] && this.#vectorEvents[layerName]["unhover"]) {
					this.#vectorEvents[layerName]["unhover"].call(this, feature);
				}
			}

			for(const i in selectFeatures) {
				const feature = selectFeatures[i];
				/*const layerName = feature.layerName;*/
                const layerName = feature.get("layerName");
				if(this.#vectorEvents[layerName] && this.#vectorEvents[layerName]["hover"]) {
					const text = this.#vectorEvents[layerName]["hover"].call(this, feature);
					if(text !== undefined && text != null) {
						this.#mouseTooltipElement.innerText = text;
						this.showMouseTooltip();
					}
				}
			}

			if(selectFeatures.length === 0) {
				this.hideMouseTooltip();
			}
		});


		if(this.#options.controlOptions && this.#options.controlOptions.isRotate) {
			const rotateCtl = new DragRotate({
				condition : (t) => {
					const e = t.originalEvent;
					return e.ctrlKey&&!(e.metaKey||e.altKey)&&!e.shiftKey;
				}
			});

			addInteractionArr.push(rotateCtl);
		}

		defaultsInteractions.extend(addInteractionArr);

		return defaultsInteractions;
	}

    showMouseTooltip() {
		this.#mouseTooltipElement.style.display = "";
	}

	hideMouseTooltip() {
		this.#mouseTooltipElement.style.display = "none";
	}
	
	createMeasureTooltip() {
		const el = document.createElement("div");
		el.className = "OLTooltip OLTooltip-measure";
		const tooltip = new Overlay({
			element : el,
			offset : [0, -15],
			positioning : "bottom-center"
		});

		this.#map.addOverlay(tooltip);
		return tooltip;
	}


    setEvent(type : string, id : string, callback : Function) {
		if(this.#events[type]) {
			this.#events[type][id] = callback;
		}
	};

	removeEvent(type : string, id : string) {
		if(this.#events[type]) {
			delete this.#events[type][id];
		}
	};


    getCenter(isTransform? : boolean, prj? : string) {
        let center = this.#view.getCenter();
        if(isTransform) {
            if(prj) {
                center = olTransform(center, this.#options.mapProj, prj);
            }else{
                center = olTransform(center, this.#options.mapProj, this.#options.dataProj);
            }
        }

        return center;
    };

    removeVectorLayer(layerId : string) {
		if(this.#layers.vector[layerId]) {

			const clickHandler = this.#interactions["vectorClickEvent"];
			const featureCollection = clickHandler.getFeatures();
			const selectFeatures = featureCollection.getArray();
			const removeFeatures = [];
			for(let i=0,cnt=selectFeatures.length; i<cnt; i++) {
				const selectF = selectFeatures[i];
				const lyrNm = selectF.get("layerName");
				if(lyrNm === layerId) {
					removeFeatures.push(selectF);
				}
			}

			for(let i=0,cnt=removeFeatures.length; i<cnt; i++) {
				const f = removeFeatures[i];
				featureCollection.remove(f);
			}

			this.#map.removeLayer(this.#layers.vector[layerId]);
			delete this.#layers.vector[layerId];

		}
	}

	parseGeometry(geom : any, geomType : string) {
		let geometry = null;
		if(!geomType) {
			geomType = "WKT";
		}
		try {
			if(typeof geom == "string") {
				if(geomType === "WKT") {
					geometry = this.#wktFormat.readGeometry(geom);
				}else{
					console.error("잘못된 Geometry Object Type입니다. 확인부탁드립니다. : " + geomType);
					return;
				}
			}else if (typeof geom == "object") {
				if(geom.length > 1) {
					if(geom.length === 2 && typeof geom[0] == "number") {
						geometry = new Point(geom);
					}else{
						const firstPoint = geom[0];
						const lastPoint = geom[geom.length - 1];

						if(geom.length > 3 && firstPoint[0] === lastPoint[0] && firstPoint[1] === lastPoint[1]) {
							geometry = new Polygon(geom);
						}else{
							geometry = new LineString(geom);
						}
					}
				}else{
					geometry = geom.clone();
				}
			}
		}catch(e) {
			console.error("Geometry로 변환간 문제가 발생되었습니다. 확인바랍니다.", e);
		}

		return geometry;
	};


	transform(geom : string | Geometry, opts : TransformOptions) {
		let geometry = null;
		const source = opts?.projection?.source ?? this.#options.dataProj;
		const target = opts?.projection?.target ?? this.#options.mapProj;
		try {
			geometry = this.parseGeometry(geom, opts.geomType);

			if(opts.isTransform) {
				geometry = geometry.transform(source, target);
			}
		}catch(e) {
			console.error("좌표변환간 에러가 발생되었습니다. 확인바랍니다.", e);
		}

		return geometry;
	}


	formatArea(polygon : Geometry, opts? : GeometryFormatOptions) {
		let geom = polygon.clone();
		geom = this.transform(geom, opts);
		const area = getArea(geom);
		let output: string | number;
		if(opts.outputType === "text") {
			if (area > 10000) {
				output = `${Math.round(area / 1000000 * 100) / 100} km<sup>2</sup>`;
			} else {
				output = `${Math.round(area * 100) / 100} m<sup>2</sup>`;
			}
		}else{
			output = area;
		}

		return output;
	}


	formatLength(line : Geometry, opts? : GeometryFormatOptions) {
		let geom = line.clone();
		geom = this.transform(geom, opts);
		const length = getLength(geom);

		let output: string | number;
		if(opts.outputType === "text") {
			if (length > 100) {
				output = `${Math.round(length / 1000 * 100) / 100} km`;
			} else {
				output = `${Math.round(length * 100) / 100} m`;
			}
		}else{
			output = length;
		}
		return output;
	}



	setMeasureControl(type : string) {
		if(this.#interactions["measureControl"]) {
			this.#isMeasureMode = null;
			this.#map.removeInteraction(this.#interactions["measureControl"]);
			delete this.#interactions["measureControl"];
		}

		if(type && type !== OLMap.CODE.MEASURE_CONTROL.NONE) {
			const source = this.#layers.vector["measureControl"].getSource();

			this.#interactions["measureControl"] = new Draw({
				source : source,
				type : type === OLMap.CODE.MEASURE_CONTROL.AREA ? "Polygon" : "LineString",
				style: this.#drawingStyle
			});
			this.#map.addInteraction(this.#interactions["measureControl"]);

			this.#isMeasureMode = type;

			let listener = null;
			let sketch = null;
			let measureId = null;
			this.#measureTooltip = this.createMeasureTooltip();

            this.#interactions["measureControl"].on("drawstart", (evt : DrawEvent) => {
               sketch = evt.feature;
               let tooltipCoord : Coordinate;
               measureId = Math.round((Math.random() * 1000000000000));
               listener = sketch.getGeometry().on("change", (e : BaseEvent) => {
                  const geom = e.target;
                  let output: string | number;

                  if(geom instanceof Polygon) {
                      output = this.formatArea(geom, {outputType : "text"});
                      tooltipCoord = geom.getInteriorPoint().getCoordinates();
                  }else if(geom instanceof LineString) {
                      output = this.formatLength(geom, {outputType : "text"});
                      tooltipCoord = geom.getLastCoordinate();
                  }

                  const el = this.#measureTooltip.getElement();
				   if (typeof output === "string") {
					   el.innerHTML = output;
				   }else{
					   el.innerHTML = `${output}`;
				   }
	              this.#measureTooltip.setPosition(tooltipCoord);
               });
            });

            this.#interactions["measureControl"].on("drawend", (evt : DrawEvent) => {
                const el = this.#measureTooltip.getElement();

	              if(type === OLMap.CODE.MEASURE_CONTROL.LENGTH) {
	            	  const id = el.getAttribute("measureid");
	            	  const tlpList = document.querySelectorAll(".OLTooltip-static.sub[measureid='"+id+"'][measurecnt='"+this.#measureCnt+"']");
					  let tlp : Element;

	            	  if(tlpList.length) {
	            		  tlp = tlpList[0];
	            		  tlp.className = tlp.className.replace("sub", "");
	            	  }
	              }

				  el.className = 'OLTooltip OLTooltip-static';
	              this.#measureTooltip.setOffset([0, -7]);
	              this.#measureStaticTooltipList.push(el);
	              this.#measureTooltip = this.createMeasureTooltip();

	              sketch = null;
	              unByKey(listener);
	              this.#measureCnt = 0;
            });
		}else{
			this.removeAllFeatures("measureControl");
			for(let i=0,cnt=this.#measureStaticTooltipList.length; i<cnt; i++) {
				const el = this.#measureStaticTooltipList[i];
				if(el != null && el.parentNode != null) {
					if(el.parentNode.parentNode != null) {
						el.parentNode.parentNode.removeChild(el.parentNode);
					}else{
						el.parentNode.removeChild(el);
					}

				}
			}
			this.#measureStaticTooltipList = [];
			const tgtElement = this.#map.getTargetElement().getElementsByClassName("OLTooltip OLTooltip-measure");
			for(let i=0,cnt=tgtElement.length; i<cnt; i++) {
				let el = tgtElement[i];
				if(el != null && el.parentNode != null) {
					if(el.parentNode.parentNode != null) {
						el.parentNode.parentNode.removeChild(el.parentNode);
					}else{
						el.parentNode.removeChild(el);
					}
				}
			}
		}
		//measureControl
	};

	#keyUpEventListener(evt : KeyboardEvent) {
		if(evt.key === "Delete") {
			if(this.#drawSelectFeature != null) {
				const hoverHandler = this.#interactions["vectorHoverEvent"];
				const featureCollection = hoverHandler.getFeatures();
				featureCollection.remove(this.#drawSelectFeature);
				const clickHandler = this.#interactions["vectorClickEvent"];
				const featureCollection2 = clickHandler.getFeatures();
				featureCollection2.remove(this.#drawSelectFeature);

				const layer = this.#layers.vector["drawControl"];
				const source = layer.getSource();
				source.removeFeature(this.#drawSelectFeature);
				this.#drawSelectFeature = null;
				this.hideMouseTooltip();
				this.drawendTriggerFunction(this.#drawCallback);
			}
		}
	}

	drawendTriggerFunction(callback : Function) {
		const layer = this.#layers.vector["drawControl"];
		const source = layer.getSource();
		const features = source.getFeatures();
		const geomArr = [];

		for(const i in features) {
			const feature = features[i];
			const geometry = feature.getGeometry();
			const attribute = feature.getProperties();
			const geomType = attribute.geomType;
			let radius = 0;
			let center = [0,0];

			let geom : Geometry = null;
			let geomStr = "";
			if(geomType === "Circle") {
				radius = attribute.radius;
				center = getOlCenter(geometry.getExtent());
				center =  olTransform(center, this.#options.mapProj, this.#options.dataProj);
				geom = circular(center, radius);
			}else if(geomType === "Polygon" || geomType === "LineString"){
				center = getOlCenter(geometry.getExtent());
				center =  olTransform(center, this.#options.mapProj, this.#options.dataProj);
				geom = geometry.clone();
				geom.transform(this.#options.mapProj, this.#options.dataProj);
			}else{
				geom = geometry.clone();
				geom.transform(this.#options.mapProj, this.#options.dataProj);
				center = (geom as Point).getCoordinates();
			}

			geomStr = this.#wktFormat.writeGeometry(geom);

			geomArr[i] = {
					type : geomType,
					radius : radius,
					center : center,
					geom : geomStr
			};
		}

		callback.call(this, geomArr);
	}

	#drawHoverCallback(feature : FeatureLike) {
		this.#drawSelectFeature = feature;
		this.#mouseTooltipElement.innerText = this.#options.drawHoverText;
		this.showMouseTooltip();
	}

	#drawUnHoverCallback(feature : FeatureLike) {
		this.#drawSelectFeature = null;
		this.hideMouseTooltip();
	}


	#drawFeatureHoverEventTrigger(e : MapBrowserEvent<any>) {
		const pixel = this.#map.getEventPixel(e.originalEvent);
		const hit = this.#map.hasFeatureAtPixel(pixel);
		if(hit) {
			this.#map.forEachFeatureAtPixel(e.pixel, (feature, layer) => {
				if(feature) {
					if(layer && layer.get("name") === "drawControl") {
						this.#drawHoverCallback(feature);
					}else{
						this.#drawUnHoverCallback(feature);
					}
				}else{
					this.#drawUnHoverCallback(feature);
				}
			});
		}else{
			this.#drawUnHoverCallback(null);
		}
	}

	#checkDrawType(type : string) {
		let output : Type = null;
		switch(type.toUpperCase()) {
			case "POINT" :
				output = "Point";
				break;
			case "LINE" :
				output = "LineString";
				break;
			case "POLYGON" :
				output = "Polygon";
				break;
			case "MULTI_POINT" :
				output = "MultiPoint";
				break;
			case "MULTI_LINE" :
				output = "MultiLineString";
				break;
			case "MULTI_POLYGON" :
				output = "MultiPolygon";
				break;
			case "CIRCLE" :
				output = "Circle";
				break;
			default :
		}
		return output;
	}

	createFeature(geom : string | Geometry, opts : CreateFeatureOptions) {
		if(!opts) opts = {};

		const geometry = this.transform(geom, opts);
		let labelGeometry = null;

		if(opts.labelGeom) {
			labelGeometry = this.transform(opts.labelGeom, opts);
		}

		const feature = new Feature({
			geometry : geometry,
			labelPoint : labelGeometry
		});

		if(opts.attributes) {
			feature.setProperties(opts.attributes);
		}

		if(opts.style) {
			feature.setStyle(opts.style);
		}

		return feature;
	}

	setCenter(center : Coordinate, prj? : string) {
		let pos = center;
		if(prj) {
			pos = olTransform(center, prj, this.#options.mapProj);
		}

		this.#view.setCenter(pos);
	}

	setZoom(zoom : number) {
		this.#view.setZoom(zoom);
	}

    setDrawControl(typeStr : string, opts? : DrawControlOptions) {
		if(!opts) opts = {};
		document.body.removeEventListener("keyup", this.#keyUpEventListener);
		this.#map.un("pointermove", this.#drawFeatureHoverEventTrigger);
		if(this.#interactions["drawControl"]) {
			this.#map.removeInteraction(this.#interactions["drawControl"]);
			delete this.#interactions["drawControl"];
		}
		if(this.#interactions["modifyControl"]) {
			this.#map.removeInteraction(this.#interactions["modifyControl"]);
			delete this.#interactions["modifyControl"];
		}
		if(this.#interactions["snapControl"]) {
			this.#map.removeInteraction(this.#interactions["snapControl"]);
			delete this.#interactions["snapControl"];
		}

		let type : Type = this.#checkDrawType(typeStr);

		if(type) {
			let style = (feature : FeatureLike, resolution : Array<any>, typ : string) => {
				if(typ) {
					return this.#drawingStyle;
				}else{
					return this.#measureStyle;
				}
			};

			if(opts.style) {
				style = opts.style;
			}

			const drawLayer = this.setVectorLayer("drawControl", {
				style : style,
				zIndex : 99999998
			});

			this.#map.on("pointermove", this.#drawFeatureHoverEventTrigger.bind(this));

			const drawSource = drawLayer.getSource();

			document.body.addEventListener("keyup", this.#keyUpEventListener.bind(this));

			const drawCallback = opts.event === undefined ? null : opts.event;
			const radius = opts.radius === undefined ? null : opts.radius;
			const beforeFeatures = opts.features === undefined ? null : opts.features;

			if(beforeFeatures && beforeFeatures.length) {

				for(const i in beforeFeatures) {
					const data = beforeFeatures[i];
					const featureType = data.type;

					let f = null;
					let featureAttr = {
						geomType : featureType,
						radius : 0
					};

					if(featureType === "Circle") {
						const geom = olTransform(data.center, this.#options.dataProj, this.#options.mapProj);
						const resolutionAtEquator = this.#view.getResolution();
						const pointResolution = getPointResolution(this.#options.mapProj, resolutionAtEquator, geom);
						const resolutionFactor = resolutionAtEquator/pointResolution;
						const viewRadius = (data.radius / METERS_PER_UNIT.m) * resolutionFactor;
						const circleGeom = new Circle(geom, viewRadius);
						f = new Feature({
							geometry : circleGeom
						});
						featureAttr.radius = data.radius;
					}else{
						f = this.createFeature(data.geom, {
							isTransform : true
						});
					}

					f.layerName = "drawControl";
					f.setProperties(featureAttr);

					drawSource.addFeature(f);
				}
			}

			let drawType : Type = type;

			if(type === "Circle" && typeof radius == "number" && radius > 0) {
				drawType = "Point";
			}

			const drawControl = new Draw({
				type : drawType
			});

			this.#drawCallback = drawCallback;

			const modifyControl = new Modify({
				source : drawSource
			});

			const snapControl = new Snap({
				source : drawSource
			});

			this.#map.addInteraction(drawControl);
			this.#map.addInteraction(modifyControl);
			this.#map.addInteraction(snapControl);
			this.#interactions["drawControl"] = drawControl;
			this.#interactions["modifyControl"] = modifyControl;
			this.#interactions["snapControl"] = snapControl;

			drawControl.on("drawend", (e) => {
				const f = e.feature;
				const layer = this.#layers.vector["drawControl"];

				f.set("layerName", "drawControl");

				if(layer) {
					const source = layer.getSource();
					let geomType = f.getGeometry().getType();
					const geom = f.getGeometry().clone();

					let r = 0;

					if(geomType === "Circle") {
						const center = olTransform((geom as Circle).getCenter(), this.#options.mapProj, "EPSG:4326");
						const lastPoint = olTransform((geom as Circle).getLastCoordinate(), this.#options.mapProj, "EPSG:4326");
						r = getDistance(center, lastPoint);
					}else if(geomType === "Point" && type === "Circle") {
						r = radius;
						const resolutionAtEquator = this.#view.getResolution();
						const pointResolution = getPointResolution(this.#options.mapProj, resolutionAtEquator, (geom as Point | Circle).getCoordinates());
						const resolutionFactor = resolutionAtEquator / pointResolution;
						const viewRadius = (r / METERS_PER_UNIT.m) * resolutionFactor;
						const circleGeom = new Circle((geom as Point | Circle).getCoordinates(), viewRadius);
						f.setGeometry(circleGeom);
						geomType = "Circle";
					}

					f.setProperties({
						geomType : geomType,
						radius : r
					});

					source.addFeature(f);

					this.drawendTriggerFunction(drawCallback);
				}

			});

			modifyControl.on("modifyend", (e) => {
				const features = e.features.getArray();
				const layer = this.#layers.vector["drawControl"];

				if(layer) {
					for(let i=0,cnt=features.length;i<cnt; i++) {
						const f = features[i];
						let geomType = f.getGeometry().getType();

						let r = 0;

						if(geomType === "Circle") {
							const circle = f.getGeometry();
							const center = olTransform((circle as Circle).getCenter(), this.#options.mapProj, "EPSG:4326");
							const lastPoint = olTransform((circle as Circle).getLastCoordinate(), this.#options.mapProj, "EPSG:4326");
							r = getDistance(center, lastPoint);

							f.setProperties({
								geomType : geomType,
								radius : r
							});
						}
					}

					this.drawendTriggerFunction(drawCallback);
				}
			});
		}else{
			this.#drawCallback = null;
			this.removeVectorLayer("drawControl");
		}
	}


	removeAllFeatures(layerId : string) {
		const layer = this.#layers.vector[layerId];

		if(layer) {
			layer.getSource().clear();
		}
	}


    setVectorLayer(layerId : string, opts? : VectorLayerOptions) {
		this.removeVectorLayer(layerId);

		if(!opts) opts = {};
		let source = opts.source;
		let style = opts.style;

		if(!source) {
			source = new VectorSource({
				strategy : bbox
			});
		}

		if(!style) {
			style = () => {
				return this.#defaultStyle;
			};
		}

		const vectorOpts = {
				name : layerId,
				layerType : "VECTOR",
				style : style,
				source : source,
                visible : true,
				extent : null
		};

		if(typeof opts.visible != "undefined") {
			vectorOpts.visible = opts.visible;
		}

		if(opts.extent) {
			if(opts.isTransform) {
				vectorOpts.extent = olTransformExtent(opts.extent, this.#options.dataProj, this.#options.mapProj);
			}else{
				vectorOpts.extent = opts.extent;
			}
		}

//		layers.vector[layerId] = new ol.layer.Vector(vectorOpts);
		this.#layers.vector[layerId] = new VectorImage(vectorOpts);

		/*if(opts.zIndex && typeof opts.zIndex == "number") {
			changeLayerZIndex("vector", layerId, opts.zIndex);
		}*/

		this.#map.addLayer(this.#layers.vector[layerId]);

		if(opts.features) {
			this.addFeatures(layerId, opts.features);
		}

		let lyrEvnts = opts.events;
		if(lyrEvnts) {
			this.#vectorSelectLayer.push(this.#layers.vector[layerId]);
			this.#vectorEvents[layerId] = {};
			if(lyrEvnts["select"]) {
				this.#vectorEvents[layerId]["select"] = lyrEvnts["select"];
			}
			if(lyrEvnts["unselect"]) {
				this.#vectorEvents[layerId]["unselect"] = lyrEvnts["unselect"];
			}
			if(lyrEvnts["hover"]) {
				this.#vectorEvents[layerId]["hover"] = lyrEvnts["hover"];
			}
			if(lyrEvnts["unhover"]) {
				this.#vectorEvents[layerId]["unhover"] = lyrEvnts["unhover"];
			}
		}

		return this.#layers.vector[layerId];
	}

    addFeature(layerId : string, feature : Feature) {
        this.addFeatures(layerId, [feature]);
    }

    addFeatures(layerId : string, features : Array<Feature>) {
		if(features.length === 0) {
			return;
		}

		if(this.#layers.vector[layerId]) {
			for(let i=0,cnt=features.length; i<cnt; i++) {
				let feature = features[i];
                feature.set("layerName", layerId);
			}

			this.#layers.vector[layerId].getSource().addFeatures(features);
		}
	}

	removeWmsLayer(layerId : string) {
		const layer = this.#layers.wms[layerId];
		if(layer) {
			this.#map.removeLayer(layer);
			delete this.#layers.wms[layerId];
		}
	}

    transformExtent(ext : Extent, opts : TransformOptions) {
		let output = ext;
		if(!opts) opts = {};
		if(!opts.projection) opts.projection = {};
		const source = opts.projection.source === undefined ? this.#options.dataProj : opts.projection.source;
		const target = opts.projection.target === undefined ? this.#options.mapProj : opts.projection.target;
		try {
			if(opts.isTransform) {
				output = olTransformExtent(ext, source, target);
			}
		}catch(e) {
			console.error("좌표변환간 에러가 발생되었습니다. 확인바랍니다.", e);
		}

		return output;
	}


	setWmsLayer(layerId : string, opts : SetWmsOptions) {
		this.removeWmsLayer(layerId);

		const params : WmsParams = opts.params;
		params.VERSION = params.VERSION === undefined ? "1.3.0" : params.VERSION;
		params._t = new Date().getTime();

		const wmsOptions : WmsOptions  = {
				name : layerId,
				layerType : "WMS"
		};

		if(opts.extent) {
			wmsOptions.extent = this.transformExtent(opts.extent, {
				projection : opts.projection
			});
		}

		if(opts.opacity !== undefined) {
			wmsOptions.opacity = opts.opacity;
		}

		if(opts.visible !== undefined) {
			wmsOptions.visible = opts.visible;
		}

		let sourceObj : any = null;
		let layerObj = null;
		let eventsName : any[] = [];
		if(opts.isSingleTile) {
			sourceObj = ImageWMS;
			layerObj = ImageLayer;
			eventsName = ["imageloadend", "imageloaderror", "error"];
		}else{
			params.tiled = true;
			sourceObj = TileWMS;
			layerObj = TileLayer;
			eventsName = ["tileloadend", "tileloaderror", "error"];
		}

		/*let sourceProjection = null;

		if(opts.isTransform) {
			if(opts.projection && opts.projection.target) {
				sourceProjection = opts.projection.target;
			}else{
				sourceProjection = this.#options.mapProj;
			}
		}else{
			if(opts.projection && opts.projection.source) {
				sourceProjection = opts.projection.source;
			}else{
				sourceProjection = this.#options.dataProj;
			}
		}*/
		const sourceOptions : ImageWMSSourceOptions | TileWMSSourceOptions = {
			url : opts.url,
			crossOrigin: "Anonymous",
//					projection: sourceProjection,
			params : params
		};

		if(opts.method && opts.method === "POST") {
			if(sourceOptions instanceof ImageWMS) {
				sourceOptions.setImageLoadFunction(this.#postImageRequest);
			}else if(sourceOptions instanceof TileWMS) {
				sourceOptions.setTileLoadFunction(this.#postTileRequest);
			}
		}

		wmsOptions.source = new sourceObj(sourceOptions);

		if(opts.event) {
			//wmsOptions.source.on(eventsName, opts.event);
			if(wmsOptions.source instanceof ImageWMS) {
				wmsOptions.source.on(eventsName, opts.event);
			}else if(wmsOptions.source instanceof TileWMS) {
				wmsOptions.source.on(eventsName, opts.event);
			}
		}

		this.#layers.wms[layerId] = new layerObj(wmsOptions);

		if(opts.zIndex && typeof opts.zIndex == "number") {
			//changeLayerZIndex("wms", layerId, opts.zIndex);
		}

		this.#map.addLayer(this.#layers.wms[layerId]);

		return this.#layers.wms[layerId];
	}

	mergeNewParam(layerId : string, params : WmsParams) {
		const layer = this.#layers.wms[layerId];
		if(layer) {
			layer.getSource().updateParams(params);
		}
	}

	removeImageLayer(layerId : string){
		const layer = this.#layers.image[layerId];
		if(layer) {
			this.#map.removeLayer(layer);
			delete this.#layers.image[layerId];
		}
	}

	setImageLayer(layerId : string, opts : SetImageOptions) {
		this.removeImageLayer(layerId);

		let url = opts.url;
		if(url.indexOf("?") !== -1) {
			url += "&time="+(new Date().getTime());
		}else{
			url += "?time="+(new Date().getTime());
		}

		const option : ImageSourceOptions = {
			url : url,
			crossOrigin : "Anonymous",
			imageExtent : this.transformExtent(opts.extent, opts)
		};

		let sourceProjection = null;

		if(opts.isTransform) {
			if(opts.projection && opts.projection.target) {
				sourceProjection = opts.projection.target;
			}else{
				sourceProjection = this.#options.mapProj;
			}
		}else{
			if(opts.projection && opts.projection.source) {
				sourceProjection = opts.projection.source;
			}else{
				sourceProjection = this.#options.dataProj;
			}
		}

		option.projection = sourceProjection;

		if(opts.size) {
			option.imageSize = opts.size;
		}

		let opacity = 1;
		if(opts.opacity) {
			opacity = opts.opacity;
		}
		var source = new ImageStatic(option);

		if(opts.event) {
			source.on(["imageloadend", "imageloaderror"], opts.event);
		}

		this.#layers.image[layerId] = new ImageLayer({
			opacity : opacity,
		    source: source
		  });

		/*if(opts.zIndex && typeof opts.zIndex == "number") {
			changeLayerZIndex("image", layerId, opts.zIndex);
		}*/

		this.#map.addLayer(this.#layers.image[layerId]);

		return this.#layers.image[layerId];
	}


	#postTileRequest(tile : ImageTile, src : string) {
		const img : HTMLImageElement | HTMLCanvasElement | HTMLVideoElement | ImageBitmap = tile.getImage();
		this.#postWmsRequest(img, src);
	}

    #postImageRequest(image : Image, src : string) {
		const img : HTMLImageElement | HTMLCanvasElement | HTMLVideoElement | ImageBitmap = image.getImage();
		this.#postWmsRequest(img, src);
	}

	#postWmsRequest(img : HTMLImageElement | HTMLCanvasElement | HTMLVideoElement | ImageBitmap, src : string) {
		if(img instanceof HTMLImageElement) {
			if (typeof window.btoa === 'function') {
			  const urlArray = src.split("?");
			  const url = urlArray[0];
			  const params = urlArray[1];

			  const xhr = new XMLHttpRequest();
			  xhr.onload = function (e) {
				if (this.status === 200) {
				  const uInt8Array = new Uint8Array(this.response);
				  let i = uInt8Array.length;
				  const binaryString = new Array(i);
				  while (i--) {
					binaryString[i] = String.fromCharCode(uInt8Array[i]);
				  }
				  const data = binaryString.join('');
				  const type = xhr.getResponseHeader('content-type');
				  if (type.indexOf('image') === 0) {
					img.src = 'data:' + type + ';base64,' + window.btoa(data);
				  }else{
					  img.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";
				  }
				}else{
					img.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";
				}
			  };
			  xhr.open('POST', url, true);
			  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			  xhr.responseType = 'arraybuffer';
			  xhr.send(params);
			} else {
			  img.src = src;
			}
		}
	}



    dispose() {
        this.#map.dispose();
    }

}

export default OLMap;