import React, {FC, useRef} from "react";
import {useHistory} from "react-router-dom";
import AuthComponent from "../components/auth/AuthComponent";


export default function Auth() {

    /*const history = useHistory();
    const handleRedirect = () => {
        history.push("/");
    }*/

  return (
      <AuthComponent/>
  );
}