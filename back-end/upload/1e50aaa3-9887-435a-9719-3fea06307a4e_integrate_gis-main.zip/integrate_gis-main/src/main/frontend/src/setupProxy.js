const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  /*app.use(
    '/wms',
    createProxyMiddleware({
      target: 'http://192.168.0.252:18080/geoserver/gyeonggi_work/wms',
      changeOrigin: true,
      secure: true,
      withCredentials: true,
    })
  );*/
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'http://localhost:8080',	// 서버 URL or localhost:설정한포트번호
      changeOrigin: true,
      secure: true, // HTTPS와 HTTP 간의 불일치 허용
      withCredentials : true,
    })
  );
};