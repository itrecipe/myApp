//TODO Sample임 나중에 삭제 필요

import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface UserState {
  name: string;
  auth : string[];
  loggedIn: boolean;
}

const initialState: UserState = {
  name: "",
  auth: [],
  loggedIn : false,
};

interface LoginPayload {
  name: string;
  auth: string[];
}

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    login: (state, action: PayloadAction<LoginPayload>) => {
      if (!action.payload.name || action.payload.auth.length === 0) {
        console.warn("Invalid login payload:", action.payload);
        return; // 상태 업데이트 방지
      }
      state.name = action.payload.name;
      state.auth = action.payload.auth;
      state.loggedIn = true;
    },
    logout: (state) => {
      Object.assign(state, initialState); // 초기 상태 복원
    },
  },
});

export const { login, logout } = userSlice.actions;
export default userSlice.reducer; // 리듀서 export
