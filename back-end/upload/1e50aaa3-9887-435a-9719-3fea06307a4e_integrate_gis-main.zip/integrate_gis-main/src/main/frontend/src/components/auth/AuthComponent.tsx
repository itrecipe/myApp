import React, {FC, useRef, useState} from "react";
import {
    DefaultDivStyle,
    ContentCentroidStyle,
    FullFlexCentroidStyle,
    ContentDivTitleStyle,
    StyledInput
} from "../../styles/CommonStyle";
import AuthAPI, {UserInfoResponse} from "../../api/AuthAPI";
import {useHistory} from "react-router-dom";
import {useDispatch} from "react-redux";
import {login, logout} from "../../store/slices/UserSlice";


const AuthComponent : FC = (props) => {
    const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
    const [id, setId] = useState("");
    const [pw, setPw] = useState("");
    const history = useHistory();
    const dispatch = useDispatch();

    dispatch(logout());

    const idKeyDown = (e : React.KeyboardEvent<HTMLInputElement>, index : number) => {
        if(e.key === "Enter") {
            if(index === 0) {
                inputRefs.current[1]?.focus();
            }else{
                submit();
            }
        }
    }

    const submit = () => {
        AuthAPI.signIn(id, pw, (result : UserInfoResponse) => {
             console.log(result);

             dispatch(login({
                 name : result.username,
                 auth : result.auth
             }));

            history.push("/map");
        });
    }

    return <FullFlexCentroidStyle>
        <DefaultDivStyle width={"400px"}>
            <ContentDivTitleStyle width={"400px"} fontSize={"20px"} height={"70px"}>GS 리테일 - 통합 GIS 플랫폼</ContentDivTitleStyle>
            <ContentCentroidStyle width={"400px"}>
                <ContentCentroidStyle width={"80px"} height={"32px"}>아이디 : </ContentCentroidStyle>
                <StyledInput
                    width={"calc(100% - 80px)"}
                    ref={(el: HTMLInputElement | null) => {
                        inputRefs.current[0] = el;
                      }}
                    placeholder={"ID"}
                    autoFocus={true}
                    onChange={(e) => setId(e.target.value)}
                    onKeyDown={(event : React.KeyboardEvent<HTMLInputElement>) => idKeyDown(event, 0)} />
            </ContentCentroidStyle>
            <ContentCentroidStyle width={"400px"}>
                <ContentCentroidStyle width={"80px"} height={"32px"}>패스워드 : </ContentCentroidStyle>
                <StyledInput
                    width={"calc(100% - 80px)"}
                    ref={(el: HTMLInputElement | null) => {
                        inputRefs.current[1] = el;
                      }}
                    placeholder={"PassWord"}
                    type={"password"}
                    onChange={(e) => setPw(e.target.value)}
                    onKeyDown={(event : React.KeyboardEvent<HTMLInputElement>) => idKeyDown(event, 1)}
                />
            </ContentCentroidStyle>
            <ContentDivTitleStyle width={"400px"} height={"40px"}>
                <button onClick={submit}>로그인</button>
            </ContentDivTitleStyle>
        </DefaultDivStyle>
    </FullFlexCentroidStyle>
};

export default AuthComponent