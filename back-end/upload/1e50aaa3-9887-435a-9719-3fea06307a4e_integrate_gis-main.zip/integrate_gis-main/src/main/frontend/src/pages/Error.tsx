import React from "react";
import {
    ErrorContentDivStyles,
    ErrorContentStyles,
    ErrorPageStyles,
    ErrorSubTitleSpan,
    ErrorTitleSpan
} from "../styles/ErrorPageStyle";
import {useHistory, useLocation} from "react-router-dom";
import queryString from 'query-string';


export default function Error({match}) {

    const history = useHistory();
    const location = useLocation();
    const queryParams = queryString.parse(location.search);

    const {code} = queryParams;

    const renderContent = () => {
        switch(code) {
            case "404" :
                return <>
                    페이지가 존재하지 않습니다.<br/>
                    <button onClick={() => {handleRedirect()}}>메인 페이지로 이동</button>
                </>;
            case "500" :
                return <>
                    서버에 문제가 생겼습니다.<br/> 관리자에게 문의 바랍니다.<br/>
                    <button onClick={() => {handleRedirect()}}>메인 페이지로 이동</button>
                </>;
            case "403" :
                return <>
                    세션이 종료되었습니다.<br/> 다시 접속 부탁드립니다.<br/>
                    <button onClick={() => {handleRedirect("/auth")}}>로그인 페이지 이동</button>
                </>;
            default :
                return <>
                    오류가 발생되었습니다.<br/>
                    <button onClick={() => {
                        handleRedirect()
                    }}>메인 페이지로 이동
                    </button>
                </>;
        }
    }


    const handleRedirect = (page?: string) => {
        history.push(page ? page : "/");
    }

  return (
      <>
          <ErrorPageStyles>
              <ErrorTitleSpan>{code}</ErrorTitleSpan><ErrorSubTitleSpan>Error!!</ErrorSubTitleSpan>
          </ErrorPageStyles>
          <ErrorContentDivStyles>
              <ErrorContentStyles>
                  {renderContent()}
              </ErrorContentStyles>
          </ErrorContentDivStyles>
      </>
  );
}