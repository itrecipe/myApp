import styled from "styled-components";
import React from "react";

interface WidthStyleProps {
  width? : string;
}

export const StyledInput = styled(
  React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
    (props, ref) => <input {...props} ref={ref} />
  )
)<WidthStyleProps>`
  display: block;
  font-size: 12px;
  width: ${(props) => props.width || "100%"};
  margin-left: 5px;
  padding: 8px;
  border-color: hsl(0, 0%, 80%);
  border-radius: 4px;
  border-style: solid;
  border-width: 1px;
  outline: none;

  &:hover {
    border-color: #2684ff;
  }
  &:focus {
    border-color: #2684ff;
  }
`;

export const FullFlexCentroidStyle = styled.div`
    width: 100vw;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
`;

interface WidthHeightStyleProps {
  width? : string;
  height? : string;
}

interface ContentDivTitleStyleProps {
  width? : string;
  height? : string;
  fontSize? : string;
}

export const DefaultDivStyle = styled.div<WidthHeightStyleProps>`
    width: ${(props) => props.width || "auto"};
      height: ${(props) => props.height || "auto"};
`;

export const ContentCentroidStyle = styled.div<WidthHeightStyleProps>`
    width: ${(props) => props.width || "200px"};
    height: ${(props) => props.height || "auto"};
    display: flex;
    align-items: center;
`;

export const ContentDivTitleStyle = styled.div<ContentDivTitleStyleProps>`
    width: ${(props) => props.width || "200px"};
    height: ${(props) => props.height || "auto"};
    font-size: ${(props) => props.fontSize || ""};
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bolder;
`;
