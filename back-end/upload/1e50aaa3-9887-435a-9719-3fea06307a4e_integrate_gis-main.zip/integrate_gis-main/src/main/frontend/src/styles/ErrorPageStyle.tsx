import styled from "styled-components";

export const ErrorPageStyles = styled.div`
    text-align: center;
    padding-top: 40px;
`;

export const ErrorTitleSpan = styled.span`
    font-size: 70px; 
    font-weight: bold; 
    color: #a53131;
`

export const ErrorSubTitleSpan = styled.span`
    font-size: 55px; 
    font-weight: bold; 
    color: #737373;
`;

export const ErrorContentDivStyles = styled.span`
    text-align: center;
`;


export const ErrorContentStyles = styled.div`
    font-size: 25px; 
    color: #888888;
`;