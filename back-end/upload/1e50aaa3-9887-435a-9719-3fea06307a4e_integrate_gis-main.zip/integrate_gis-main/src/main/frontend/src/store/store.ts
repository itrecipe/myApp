import {combineReducers, configureStore} from "@reduxjs/toolkit";
import { persistStore, persistReducer } from "redux-persist";
import storageSession from "redux-persist/lib/storage/session";
import userReducer from "./slices/UserSlice";

const rootReducer = combineReducers({
  user: userReducer,
});

// persist 설정
const persistConfig = {
  key: "root",
  storage: storageSession,
  whitelist: ["user"], // user 리듀서만 저장
};

// persistReducer 생성
const persistedReducer = persistReducer(persistConfig, rootReducer);

// 스토어 설정
const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [
          "persist/PERSIST",
          "persist/REHYDRATE",
          "persist/FLUSH",
          "persist/PAUSE",
          "persist/PURGE",
          "persist/REGISTER",
        ],
      },
    }),
});

export const persistor = persistStore(store);

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;