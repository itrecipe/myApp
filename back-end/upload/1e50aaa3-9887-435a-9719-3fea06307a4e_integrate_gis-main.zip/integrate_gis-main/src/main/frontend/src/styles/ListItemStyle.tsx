import styled from "styled-components";

export const NavResultItemStyles = styled.div`
    width: calc(100% - 25px);
    border-color: hsl(0, 0%, 80%);
    border-radius: 4px;
    border-style: solid;
    border-width: 1px;
    padding : 5px 5px;
`;

export const NavResultItemTitleStyles = styled.h3`
    font-size : 13px;
`;


interface NavResultItemContentProps {
  text_indent? : string;
  padding_left? : string;
}


export const NavResultItemContentStyles = styled.p<NavResultItemContentProps>`
    font-size : 10px;
    text-indent: ${(props) => props.text_indent || "0px"};
    padding-left: ${(props) => props.padding_left || "0px"};
`;


