import axios from "axios";
import * as Constants from "../constants/Constants"

export type ApiParams = {
    url : string,
    params? : object,
    headers? : object,
    isRequestBody? : boolean,
    response : (result : ApiResponse) => void,
    error? : (error : object) => void
}

export type ApiResponse = {
    RESULT : "SUCCESS" | "FAILURE",
    DATA? : object,
    LIST? : [],
    MESSAGE? : string
}

export type ApiOptions = {
    url: string,
    method: string,
    data?: object,
    params?: object,
    headers?: object,
    timeout : number
}

axios.defaults.headers.common['X-Requested-By'] = `Frontend`

const APIUtils = {
    qs : require("qs"),
    timeout : 120000,


    callApi(method : string, data : ApiParams) {
        const params = data.params || {};
        const url = data.url || "";
        const apiUrl = Constants.BASEURL + url;

        const headers = data.headers || {};

        const options = {
          url: apiUrl,
          method: method,
          params: !data.isRequestBody ? (Object.keys(params).length > 0 ? params : null) : null,
          data: data.isRequestBody ? (Object.keys(params).length > 0 ? params : null) : null,
          headers: headers,
          timeout: this.timeout,
        };

        axios(options).then(response => {
            const result : ApiResponse = response.data;
            if(result.RESULT === "SUCCESS") {
                data.response.call(this, result);
            }else{
                if(data.error) {
                    data.error.call(this, result);
                }
            }
        }).catch(error => {
            if(error.status === 403) {
                alert("세션이 종료되었습니다.");
                window.location.href = "/auth";
            }else if(error.status === 401 && error.response?.data?.error === "Expired JWT token") {
                this.post({
                    url : "auth/refresh",
                    response : () => {
                        this.callApi(method,  data);
                    },error : (err : any) => {
                        if(err?.MESSAGE === "다른 사람이 접근하였습니다.") {
                            alert(err.MESSAGE);
                            window.location.href = "/auth";
                        }
                    }
                })
            }
            if(data.error) {
                data.error.call(this, error);
            }
        });
    },

    get(data : ApiParams) {
        this.callApi("GET", data);
    },

    post(data : ApiParams) {
        this.callApi("POST", data);
    }
}

export default APIUtils;