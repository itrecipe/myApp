import {Redirect, Route, Switch} from "react-router-dom";
import './styles/global.css'
import './App.css';
import {Provider} from "react-redux";
import store, {persistor} from "./store/store";
import {PersistGate} from "redux-persist/integration/react";
import pingCheck from "./components/HigherOrderComponent";
import {ROUTES} from "./constants/Constants";

function App() {
  return (
      <Provider store={store}>
          <PersistGate loading={null} persistor={persistor}>
            <Switch>
                {ROUTES.map((route, index) => (
                    <Route
                        path={route.path}
                        key={index}
                        component={route.component}
                        exact={route.exact}
                    />
                ))}
              <Redirect to={"/error?code=404"} />
            </Switch>
          </PersistGate>
      </Provider>
  );
}

/*export default App;*/
export default pingCheck(App);
