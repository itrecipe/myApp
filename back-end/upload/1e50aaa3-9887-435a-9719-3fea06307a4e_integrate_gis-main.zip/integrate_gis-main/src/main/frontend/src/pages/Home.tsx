
import SampleAPI from "../api/SampleAPI"
import {useState} from "react";
import {useSelector} from "react-redux";
import {RootState} from "../store/store";
import {useHistory} from "react-router-dom";

export default function Home() {

    const [test, setTest] = useState("");
    const userInfo = useSelector((state: RootState) => state.user);
    const history = useHistory();

    const goAuthPage = () => {
        history.push("/auth");
    }
    
    const goMapPage = () => {
        history.push("/map");
    }

  return (
    <div>
      <h1>Home</h1>
      <p>
          {
              userInfo.loggedIn ?
                  <>
                      <h2>{userInfo.name}님 안녕하세요.</h2>
                      <button onClick={goMapPage}>지도페이지</button>
                  </> :
                  <button onClick={goAuthPage}>로그인</button>
          }
      </p>
    </div>
  );
}