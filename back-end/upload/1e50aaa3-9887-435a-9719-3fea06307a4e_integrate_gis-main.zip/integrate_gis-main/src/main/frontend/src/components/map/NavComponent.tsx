import styled from "styled-components";
import {FC, useEffect, useState} from "react";
import {useMap} from "../../context/MapContext";
import OLMap, {DrawData} from "../../utils/OLMap";
import AddressSearchComponent from "./Nav/AddressSearchComponent";
import {useDispatch, useSelector} from "react-redux";
import {RootState} from "../../store/store";
import {useHistory} from "react-router-dom";
import AuthAPI from "../../api/AuthAPI";
import {login, logout} from "../../store/slices/UserSlice";
import {BASEURL} from "../../constants/Constants";


interface NavStylesProps {
  width? : string;
}

interface NavComponentProps {
  width? : string;
}

export const NavStyles = styled.div<NavStylesProps>`
  width: ${(props) => props.width || "200px"};
  height: 100vh;
  overflow: hidden;
`;

const NavComponent: FC<NavComponentProps> = (props) => {
    const {map, isInitialized} = useMap();
    const [isImageLayer, setIsImageLayer] = useState(false);
    const userInfo = useSelector((state: RootState) => state.user);
    const history = useHistory();
    const dispatch = useDispatch();

    const drawCallback = (geomArr : Array<DrawData>) => {
        console.log(geomArr);
    }

    const setMeasureControl= (type : string) => {
        if(map) {
            map.setMeasureControl(type);
            if(type === OLMap.CODE.MEASURE_CONTROL.NONE) {
                map.setDrawControl(OLMap.CODE.DRAW_TYPE.NONE);
            }
        }
    }

    const setDrawControl = (type : string) => {
        if(map) {
            if(type === "RADIUS_CIRCLE") {
                map.setDrawControl(OLMap.CODE.DRAW_TYPE.CIRCLE, {
                    radius : 1000,
                    event : drawCallback
                });
            }else{
                map.setDrawControl(type, {
                    event : drawCallback
                });
            }
        }
    }

    const goAuthPage = () => {
        history.push("/auth");
    }

    const logoutAction = () => {
        AuthAPI.signOut((result) => {
            console.log(result);
            dispatch(logout());
            history.push("/");
        });
    }

    const changeLifeAreaView = (type : "float_style" | "ecopop_style") => {
        if(map) {
            map.mergeNewParam("testLayer", {
               STYLES : type
            });
        }
    }
    
    const showImageLayer = () => {
        if(map) {
            if(isImageLayer) {
                map.removeImageLayer("testLayer2");
            }else{
                map.setImageLayer("testLayer2", {
                    url : BASEURL + "api/sample/sampleImage",
                    extent : [121.5568231, 30.7637945, 132.5214940, 40.5955843],
                    isTransform : true,
                    opacity : 0.5
                })
            }

            setIsImageLayer(!isImageLayer);
        }
        
    }

    useEffect(() => {
    if (isInitialized && map) {
      /*map.setWmsLayer("testLayer", {
          url : "http://192.168.0.252:18080/geoserver/gyeonggi_work/wms",
          params : {
                LAYERS : "gyeonggi_work:life_area_analysis",
              /!*VERSION : "1.1.1"*!/
          },
          visible : true
      });*/
    }
  }, [isInitialized, map]);

    return <NavStyles width={props.width}>
        {
            userInfo.loggedIn ?
                <>
                    <h2>{userInfo.name}님 안녕하세요.</h2>
                    <button onClick={logoutAction}>로그아웃</button>
                </> :
                <button onClick={goAuthPage}>로그인</button>
        }
        <br/>
        <button onClick={() => setMeasureControl(OLMap.CODE.MEASURE_CONTROL.AREA)}>면적재기</button>
        <button onClick={() => setMeasureControl(OLMap.CODE.MEASURE_CONTROL.LENGTH)}>거리재기</button>
        <button onClick={() => setMeasureControl(OLMap.CODE.MEASURE_CONTROL.NONE)}>종료하기</button>
        <button onClick={() => setDrawControl(OLMap.CODE.DRAW_TYPE.POINT)}>점 그리기</button>
        <button onClick={() => setDrawControl(OLMap.CODE.DRAW_TYPE.LINE)}>선 그리기</button>
        <button onClick={() => setDrawControl(OLMap.CODE.DRAW_TYPE.POLYGON)}>면 그리기</button>
        <button onClick={() => setDrawControl(OLMap.CODE.DRAW_TYPE.CIRCLE)}>원 그리기</button>
        <button onClick={() => setDrawControl("RADIUS_CIRCLE")}>원(반경 1Km) 그리기</button>
        <button onClick={() => changeLifeAreaView("float_style")}>생활인구(직장인)</button>
        <button onClick={() => changeLifeAreaView("ecopop_style")}>경제활동인구수</button>
        <button onClick={() => showImageLayer()}>위성사진</button>
        <AddressSearchComponent height={"calc(100vh - 100px)"}></AddressSearchComponent>
    </NavStyles>
}

export default NavComponent