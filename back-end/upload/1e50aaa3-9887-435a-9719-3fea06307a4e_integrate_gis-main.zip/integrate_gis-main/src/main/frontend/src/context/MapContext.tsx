import React, {createContext, useContext, useRef, useEffect, useState} from "react";
import OLMap from "../utils/OLMap";
import {Tile} from "ol/layer";
import {XYZ} from "ol/source";
import * as Constants from "../constants/Constants"

interface MapContextProps {
  map: OLMap | null;
  isInitialized: boolean;
}

const MapContext = createContext<MapContextProps | undefined>(undefined);

export const MapProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const mapRef = useRef<OLMap | null>(null);
  const [isInitialized, setIsInitialized] = useState(false); // 초기화 완료 상태


  useEffect(() => {
    if (!mapRef.current) {
      mapRef.current = new OLMap({
        viewOptions: {
          zoom: 11
        },
        baseLayers: [
          {
            name: "BASE",
            layers: [
              new Tile({
                source: new XYZ({
                  url: `https://api.vworld.kr/req/wmts/1.0.0/${Constants.VWORLD_KEY}/Base/{z}/{y}/{x}.png`,
                }),
              }),
            ],
          },
        ],
      });

      setIsInitialized(true);
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.dispose();
        mapRef.current = null;
      }
    };
  }, []);

  return (
    <MapContext.Provider value={{ map: mapRef.current, isInitialized  }}>
      {children}
    </MapContext.Provider>
  );
};

// Custom hook for consuming the context
export const useMap = (): MapContextProps => {
  const context = useContext(MapContext);
  if (!context) {
    throw new Error("useMap must be used within a MapProvider");
  }
  return context;
};
