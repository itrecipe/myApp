import React from 'react';
import AuthAPI from "../api/AuthAPI";
import {useLocation} from "react-router-dom";
import {ROUTES} from "../constants/Constants";

const pingCheck = (WrappedComponent : any) => {
    return (props : any) => {

        const location = useLocation();

        if(ROUTES.some(route => route.path === location.pathname)) {
            AuthAPI.ping((result : string) => {
               console.log(result);
            });
        }

        return <WrappedComponent {...props} />;
    };
};

export default pingCheck;
