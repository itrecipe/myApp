package com.gsretail.integrate_gis.app.auth.ctrl;

import com.gsretail.integrate_gis.app.auth.entity.UserInfo;
import com.gsretail.integrate_gis.app.auth.service.AuthService;
import com.gsretail.integrate_gis.core.jwt.entity.UserEntity;
import com.gsretail.integrate_gis.core.jwt.service.SecurityService;
import com.gsretail.integrate_gis.core.request.ResultMap;
import com.gsretail.integrate_gis.core.util.CookieUtils;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseCookie;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthRestController {

    @Value("${jwt.refresh-token-valid-seconds}")
    private Long refreshValidSeconds;

    private final AuthService authService;

    private final SecurityService securityService;

    @PostMapping("/signIn")
    public ResultMap signIn(@RequestBody UserInfo user, HttpServletResponse response) {
        ResultMap resultMap = new ResultMap();

        try {
            /*log.debug("Request SignIn : {} : {}", user.username(), user.password());*/
            String accessToken = authService.signIn(user.username(), user.password());

            CookieUtils.setAccessTokenByResponseCookie(response, accessToken, refreshValidSeconds / 1000);
            Map<String, Object> data = new HashMap<>();
            data.put("username", user.username());
            data.put("auth", securityService.selectRolesByUsername(user.username()));
            
            resultMap.setData(data);
            resultMap.setSuccess();
        }catch(Exception e) {
            log.error(e.getMessage());
        }

        return resultMap;
    }

    @PostMapping("/signOut")
    public ResultMap signOut(HttpServletRequest request, HttpServletResponse response) {
        ResultMap resultMap = new ResultMap();

        try {
            authService.signOut(request, response);
            resultMap.setSuccess();
        }catch(Exception e) {
            log.error(e.getMessage());
        }

        return resultMap;
    }

    @PostMapping("/refresh")
    public ResultMap refresh(HttpServletRequest request, HttpServletResponse response) {
        ResultMap resultMap = new ResultMap();
        try {
            String accessToken = authService.refresh(request);
            CookieUtils.setAccessTokenByResponseCookie(response, accessToken, refreshValidSeconds / 1000);

            resultMap.setSuccess();
        }catch(Exception e) {
            log.error(e.getMessage());
            resultMap.setMessage(e.getMessage());
        }

        return resultMap;
    }

    @PostMapping("/deleteAll")
    public ResultMap deleteAll() {
        ResultMap resultMap = new ResultMap();
        try {
            authService.deleteAll();
            resultMap.setSuccess();
        }catch(Exception e) {
            log.error(e.getMessage());
        }

        return resultMap;
    }
}
