package com.gsretail.integrate_gis.core.request;

import java.util.HashMap;
import java.util.List;

public class ResultMap extends HashMap<String, Object> {

    /**
     * 생성자
     */
    public ResultMap() {
        this.put(ResultCode.KEY.RESULT.getName(), ResultCode.RESULT.FAILURE.getName());
    }

    /**
     * "RESULT" 값에 상태값을 "SUCCESS"로 설정
     */
    public void setSuccess() {
        this.put(ResultCode.KEY.RESULT.getName(), ResultCode.RESULT.SUCCESS.getName());
    }

    /**
     * List 값을 세팅
     *
     * @param list the list
     */
    public void setList(List list) {
        this.put(ResultCode.KEY.LIST.getName(), list);
    }

    /**
     * 메시지 세팅
     *
     * @param message the message
     */
    public void setMessage(String message) {
        this.put(ResultCode.KEY.MESSAGE.getName(), message);
    }

    /**
     * 데이터 세팅
     *
     * @param data the data
     */
    public void setData(Object data) {
        this.put(ResultCode.KEY.DATA.getName(), data);
    }


}
