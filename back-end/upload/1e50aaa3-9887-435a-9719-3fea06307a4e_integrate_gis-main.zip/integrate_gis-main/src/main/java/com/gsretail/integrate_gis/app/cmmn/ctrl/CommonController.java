package com.gsretail.integrate_gis.app.cmmn.ctrl;

import com.gsretail.integrate_gis.core.request.ResultMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@Slf4j
public class CommonController {

    @RequestMapping({"/", "/map", "/auth"})
    public String index() {
        return "index";
    }

    @GetMapping("/ping")
    @ResponseBody
    public ResultMap ping() {
        ResultMap resultMap = new ResultMap();
        resultMap.setSuccess();
        return resultMap;
    }

}
