package com.gsretail.integrate_gis.app.smpl.service;


import com.gsretail.integrate_gis.core.util.HttpRequestUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class VworldService {
/**
	 * 주소 검색 > 도로명주소
	 */
	public static final String ADDRESS_ROAD = "ROAD";

	/**
	 * 주소 검색 > 지번주소
	 */
	public static final String ADDRESS_PARCEL = "PARCEL";

	/**
	 * 행정구역 검색 > 시도 (Level 1)
	 */
	public static final String HJD_CTPRVN = "L1";

	/**
	 * 행정구역 검색 > 시군구 (Level 2)
	 */
	public static final String HJD_SIGUNGU = "L2";

	/**
	 * 행정구역 검색 > 구 (Level 3)
	 */
	public static final String HJD_GU = "L3";

	/**
	 * 행정구역 검색 > 읍면동 (Level 4)
	 */
	public static final String HJD_EMD = "L4";

	@Value("${gsretail.api.vworld.url}")
	private String url;

	@Value("${gsretail.api.vworld.address-path}")
	private String addressPath;

	@Value("${gsretail.api.vworld.geocoder-path}")
	private String geocoderPath;

	@Value("${gsretail.api.vworld.key}")
	private String apiKey;

	@SuppressWarnings("unchecked")
	public Map<String, Object> getAddressList(String type, String keyword, Integer size, Integer page, String bbox, String crs) {
		Map<String, Object> output = new HashMap<>();

		Map<String, Object> params = new HashMap<>();
		params.put("service", "search");
		params.put("request", "search");
		params.put("version", "2.0");
		if(crs != null) {
			params.put("crs", crs);
		}
		if(bbox != null) {
			params.put("bbox", bbox);
		}
		params.put("key", apiKey);
		params.put("size", size);
		params.put("page", page);
		params.put("query", keyword);
		params.put("type", "address");
		if(type != null) {
			params.put("category", type);
		}
		params.put("format", "json");
		params.put("errorformat", "json");

		log.debug("Vworld Address Request Param : {}", params);

		Map<String, Object> result = HttpRequestUtils.getHttpData(url + addressPath, HttpMethod.POST, params, Map.class);

		Map<String, Object> response = (Map<String, Object>) result.get("response");

		String status = (String) response.get("status");

		output.put("status", status);

		if("OK".equals(status)) {
			Map<String, Object> pageAttr = (Map<String, Object>) response.get("page");

			String totalPage = (String) pageAttr.get("total");

			output.put("TotalPage", totalPage);

			Map<String, Object> resultAttr = (Map<String, Object>) response.get("result");

			List<Map<String, Object>> items = (List<Map<String, Object>>) resultAttr.get("items");

			output.put("LIST", items);
		}else {
			log.debug("Vworld Api Error : {}", response);
		}

		return output;
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> getPlaceList(String type, String keyword, Integer size, Integer page, String bbox, String crs) {
		Map<String, Object> output = new HashMap<>();

		Map<String, Object> params = new HashMap<>();
		params.put("service", "search");
		params.put("request", "search");
		params.put("version", "2.0");
		if(crs != null) {
			params.put("crs", crs);
		}
		if(bbox != null) {
			params.put("bbox", bbox);
		}
		params.put("key", apiKey);
		params.put("size", size);
		params.put("page", page);
		params.put("query", keyword);
		params.put("type", "PLACE");
		if(type != null) {
			params.put("category", type);
		}
		params.put("format", "json");
		params.put("errorformat", "json");

		log.debug("Vworld Place Request Param : {}", params);

		Map<String, Object> result = HttpRequestUtils.getHttpData(url + addressPath, HttpMethod.POST, params, Map.class);

		Map<String, Object> response = (Map<String, Object>) result.get("response");

		String status = (String) response.get("status");

		output.put("status", status);

		if("OK".equals(status)) {
			Map<String, Object> pageAttr = (Map<String, Object>) response.get("page");

			String totalPage = (String) pageAttr.get("total");

			output.put("TotalPage", totalPage);

			Map<String, Object> resultAttr = (Map<String, Object>) response.get("result");

			List<Map<String, Object>> items = (List<Map<String, Object>>) resultAttr.get("items");

			output.put("LIST", items);
		}else {
			log.debug("Vworld Api Error : {}", response);
		}

		return output;
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> getHjdList(String type, String keyword, Integer size, Integer page, String bbox, String crs) {

		Map<String, Object> output = new HashMap<>();

		Map<String, Object> params = new HashMap<>();
		params.put("service", "search");
		params.put("request", "search");
		params.put("version", "2.0");
		if(crs != null) {
			params.put("crs", crs);
		}
		if(bbox != null) {
			params.put("bbox", bbox);
		}
		params.put("key", apiKey);
		params.put("size", size);
		params.put("page", page);
		params.put("query", keyword);
		params.put("type", "DISTRICT");
		if(type != null) {
			params.put("category", type);
		}
		params.put("format", "json");
		params.put("errorformat", "json");

		log.debug("Vworld Hjd Request Param : {}", params);

		Map<String, Object> result = HttpRequestUtils.getHttpData(url + addressPath, HttpMethod.POST, params, Map.class);

		Map<String, Object> response = (Map<String, Object>) result.get("response");

		String status = (String) response.get("status");

		output.put("status", status);

		if("OK".equals(status)) {
			Map<String, Object> pageAttr = (Map<String, Object>) response.get("page");

			String totalPage = (String) pageAttr.get("total");

			output.put("TotalPage", totalPage);

			Map<String, Object> resultAttr = (Map<String, Object>) response.get("result");

			List<Map<String, Object>> items = (List<Map<String, Object>>) resultAttr.get("items");

			for(Map<String, Object> item : items) {
				String geomUrl = (String) item.get("geometry");
				geomUrl = HttpRequestUtils.getHttpData(geomUrl);
				item.put("geometry", geomUrl);
			}

			output.put("LIST", items);
		}else {
			log.debug("Vworld Api Error : {}", response);
		}

		return output;
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> getReverseGeoCoding(String crs, double lon, double lat) {
		Map<String, Object> output = new HashMap<>();

		Map<String, Object> params = new HashMap<>();
		params.put("service", "address");
		params.put("request", "getAddress");
		params.put("version", "2.0");
		if(crs != null) {
			params.put("crs", crs);
		}
		params.put("type", "BOTH");
		params.put("point", lon+","+lat);
		params.put("key", apiKey);
		params.put("format", "json");
		params.put("errorformat", "json");

		log.debug("Vworld Reverse Geocoding Request Param : {}", params);

		Map<String, Object> result = HttpRequestUtils.getHttpData(url + geocoderPath, HttpMethod.POST, params, Map.class);

		Map<String, Object> response = (Map<String, Object>) result.get("response");

		String status = (String) response.get("status");

		output.put("status", status);

		if("OK".equals(status)) {
			output.put("LIST", (List<Map<String, Object>>) response.get("result"));
		}else {
			log.debug("Vworld Api Error : {}", response);
		}

		return output;
	}

}
