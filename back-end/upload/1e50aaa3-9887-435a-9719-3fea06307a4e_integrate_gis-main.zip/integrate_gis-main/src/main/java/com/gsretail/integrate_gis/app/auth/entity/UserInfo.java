package com.gsretail.integrate_gis.app.auth.entity;

public record UserInfo(
        String username,
        String password
) {
}
