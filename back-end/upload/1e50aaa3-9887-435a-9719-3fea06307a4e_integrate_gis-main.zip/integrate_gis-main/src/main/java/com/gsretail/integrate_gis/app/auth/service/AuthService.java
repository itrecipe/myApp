package com.gsretail.integrate_gis.app.auth.service;


import com.gsretail.integrate_gis.core.jwt.dto.JwtToken;
import com.gsretail.integrate_gis.core.jwt.service.HashOperationsService;
import com.gsretail.integrate_gis.core.jwt.service.SecurityComponent;
import io.micrometer.common.util.StringUtils;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseCookie;
import org.springframework.security.authentication.AccountExpiredException;
import org.springframework.security.authentication.AccountStatusException;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Slf4j
@RequiredArgsConstructor
@Service
public class AuthService {

    private final HashOperationsService hashOperationsService;

    private final SecurityComponent securityComponent;

    @Value("${jwt.redis-refresh-token-key}")
    private String refreshKey;

    @Value("${jwt.redis-access-token-key}")
    private String accessKey;

    @Value("${jwt.refresh-token-valid-seconds}")
    private Long refreshValidSeconds;

    @Value("${jwt.access-token-valid-seconds}")
    private Long accessValidSeconds;

    public void signOut(HttpServletRequest request, HttpServletResponse response) {
        String accessToken = securityComponent.resolveCookieToken(request);
        Authentication authInfo = securityComponent.getAuthentication(accessToken);

        hashOperationsService.delete(accessKey, authInfo.getName());
        hashOperationsService.delete(refreshKey, authInfo.getName());

        ResponseCookie cookie = ResponseCookie.from("accessToken", "")
                    .httpOnly(true)
                    /*.secure(true)*/
                    .path("/")
                    .sameSite("Strict")
                    .maxAge(0)
                    .build();

        response.addHeader("Set-Cookie", cookie.toString());
    }

    public String signIn(String username, String password) {
        String output = null;

        JwtToken token = securityComponent.signIn(username, password);
        if (token != null) {
            /*output = token.getGrantType() + " " + token.getAccessToken();*/
            output = token.getAccessToken();
            hashOperationsService.put(refreshKey, username, token.getRefreshToken(), refreshValidSeconds, TimeUnit.SECONDS);
            hashOperationsService.put(accessKey, username, token.getAccessToken(), accessValidSeconds, TimeUnit.SECONDS);
            log.debug((String) hashOperationsService.get(refreshKey, username));
            log.debug("Refresh Token Size: {}", hashOperationsService.size(refreshKey));
        }
        return output;
    }

    public void deleteAll() {
        hashOperationsService.deleteAll();
    }

    public String refresh(HttpServletRequest request) throws NullPointerException {
        String newAccessToken = null;

        String accessToken = securityComponent.resolveCookieToken(request);

        Authentication authInfo = securityComponent.getAuthentication(accessToken);

        Object checkAccessToken = hashOperationsService.get(accessKey, authInfo.getName());
        Object refreshToken = hashOperationsService.get(refreshKey, authInfo.getName());

        log.debug("{} : {} : {} : {}", authInfo.getName(), accessToken, checkAccessToken, refreshToken);

        if(!StringUtils.isEmpty((String) checkAccessToken) && !checkAccessToken.equals(accessToken)) {
            throw new AccountExpiredException(("다른 사람이 접근하였습니다."));
        }

        if(refreshToken == null) {
            throw new NullPointerException("토큰을 찾을 수 없습니다.");
        }

        if(!securityComponent.validateToken((String)refreshToken)) {
            throw new AccountExpiredException("토큰의 유효기간이 만료되었습니다.");
        }

        JwtToken newToken = securityComponent.generateToken(authInfo);
        if (newToken != null) {
            /*newAccessToken = newToken.getGrantType() + " " + newToken.getAccessToken();*/
            newAccessToken = newToken.getAccessToken();
            hashOperationsService.put(refreshKey, authInfo.getName(), newToken.getRefreshToken(), refreshValidSeconds, TimeUnit.SECONDS);
            hashOperationsService.put(accessKey, authInfo.getName(), newToken.getAccessToken(), accessValidSeconds, TimeUnit.SECONDS);
            log.debug((String) hashOperationsService.get(refreshKey, authInfo.getName()));
            log.debug("Refresh Token Size: {}", hashOperationsService.size(refreshKey));
        }
        return newAccessToken;
    }

}
