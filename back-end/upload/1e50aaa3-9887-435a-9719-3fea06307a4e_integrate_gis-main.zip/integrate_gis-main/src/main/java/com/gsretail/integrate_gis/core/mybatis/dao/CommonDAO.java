package com.gsretail.integrate_gis.core.mybatis.dao;

import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.dao.support.DaoSupport;
import org.springframework.util.Assert;

import java.sql.SQLException;
import java.util.List;

@Slf4j
public class CommonDAO extends DaoSupport {

    private SqlSession sqlSession;
    private boolean externalSqlSession;

    @Override
    protected void checkDaoConfig() throws IllegalArgumentException {
        Assert.notNull(this.sqlSession, "Property 'sqlSessionFactory' or 'sqlSessionTemplate' are required");
    }

    public final void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
        if(!this.externalSqlSession) {
            this.sqlSession = sqlSessionFactory.openSession();
        }
    }

    public final void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
        this.sqlSession = sqlSessionTemplate;
        this.externalSqlSession = true;
    }

    public <Any>Any selectObject(String mapperId) throws SQLException {
		return this.sqlSession.selectOne(mapperId);
	}

	public <Any>Any selectObject(String mapperId, Object parameter) throws SQLException {
		return this.sqlSession.selectOne(mapperId, parameter);
	}

	@SuppressWarnings("rawtypes")
	public List selectList(String mapperId) throws SQLException {
		return this.sqlSession.selectList(mapperId);
	}

	@SuppressWarnings("rawtypes")
	public List selectList(String mapperId, Object parameter) throws SQLException {
		return this.sqlSession.selectList(mapperId, parameter);
	}

	public int insert(String mapperId) throws SQLException {
		return this.sqlSession.insert(mapperId);
	}

	public int insert(String mapperId, Object parameter) throws SQLException {
		return this.sqlSession.insert(mapperId, parameter);
	}

	public void insertBatch(String mapperId, List<?> parameterList) throws SQLException {
		log.debug(String.valueOf(this.sqlSession.getConfiguration().getDefaultExecutorType()));

		for(Object parameter : parameterList) {
			this.sqlSession.update(mapperId, parameter);
		}
		this.sqlSession.flushStatements();
	}

	public int update(String mapperId) throws SQLException {
		return this.sqlSession.update(mapperId);
	}

	public int update(String mapperId, Object parameter) throws SQLException {
		return this.sqlSession.update(mapperId, parameter);
	}

	public int delete(String mapperId) throws SQLException {
		return this.sqlSession.delete(mapperId);
	}

	public int delete(String mapperId, Object parameter) throws SQLException {
		return this.sqlSession.delete(mapperId, parameter);
	}

}
