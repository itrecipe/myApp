package com.gsretail.integrate_gis.core.mybatis.config;

import com.gsretail.integrate_gis.core.mybatis.dao.CommonDAO;
import com.zaxxer.hikari.HikariDataSource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.boot.autoconfigure.SpringBootVFS;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.interceptor.DefaultTransactionAttribute;
import org.springframework.transaction.interceptor.RollbackRuleAttribute;
import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
import org.springframework.transaction.interceptor.TransactionInterceptor;


import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@Slf4j
@RequiredArgsConstructor
public class DatabaseConfig {
    private final String prefix;
    private final String className;
    private final String jdbcUrl;
    private final String username;
    private final String password;
    private final Integer maxPoolSize;
    private final Integer minIdle;
    private final String validationQuery;
    private final Integer validationTimeout;
    private final Integer connectionTimeout;

    public MapperScannerConfigurer getMapperScannerConfigurer(String sessionTemplateName, String basePackage) {
        MapperScannerConfigurer configurer = new MapperScannerConfigurer();
        configurer.setBasePackage(basePackage);
        configurer.setSqlSessionFactoryBeanName(sessionTemplateName);
        return configurer;
    }

    public DataSourceProperties getDataSourceProperties() {
        DataSourceProperties dataSourceProperties = new DataSourceProperties();
        dataSourceProperties.setUrl(this.jdbcUrl);
        dataSourceProperties.setUsername(this.username);
        dataSourceProperties.setPassword(this.password);
        dataSourceProperties.setDriverClassName(this.className);
        dataSourceProperties.setName(this.prefix);
        return dataSourceProperties;
    }

    public DataSource getDataSource() {
        DataSource dataSource = null;
        if(log.isDebugEnabled()) {
            log.debug("> Database Setting("+prefix+")");
            log.debug("=====> ClassName : {}", className);
            log.debug("====> MaxPoolSize : {}", maxPoolSize);
            log.debug("=====> MinIdle : {}", minIdle);
            log.debug("=====> JdbcUrl : {}", jdbcUrl);
            log.debug("=====> User : {}", username);
            log.debug("=====> ValidationQuery : {}", validationQuery);
            log.debug("=====> ValidationTimeout : {}", validationTimeout);
            log.debug("=====> ConnectionTimeout : {}", connectionTimeout);
        }
        try {
            HikariDataSource source = getDataSourceProperties().initializeDataSourceBuilder().type(HikariDataSource.class).build();
            source.setMaximumPoolSize(maxPoolSize);
            source.setMinimumIdle(minIdle);
            source.setConnectionTimeout(connectionTimeout);
            source.setValidationTimeout(validationTimeout);
            source.setConnectionTestQuery(validationQuery);
            dataSource = source;
        }catch(Exception e) {
            log.error("Create Database Error", e);
        }
        return dataSource;
    }

    public TransactionInterceptor txInterceptor(DataSourceTransactionManager transactionManager, String[] writeMethodPrefix) {
        TransactionInterceptor interceptor = new TransactionInterceptor();
        Properties properties = new Properties();

        // 롤백 규칙 설정
        List<RollbackRuleAttribute> rollbackRuleAttributes = new ArrayList<>();
        rollbackRuleAttributes.add(new RollbackRuleAttribute(Exception.class));

        // 읽기 전용 트랜잭션 속성
        DefaultTransactionAttribute readOnlyTransactionAttribute = new DefaultTransactionAttribute(TransactionDefinition.PROPAGATION_REQUIRED);
        readOnlyTransactionAttribute.setReadOnly(true);

        // 쓰기 전용 트랜잭션 속성
        RuleBasedTransactionAttribute writeTransactionAttribute = new RuleBasedTransactionAttribute(TransactionDefinition.PROPAGATION_REQUIRED, rollbackRuleAttributes);

        // 속성 문자열로 변환
        String readOnlyTransactionAttributeDefinition = readOnlyTransactionAttribute.toString();
        String writeOnlyTransactionAttributeDefinition = writeTransactionAttribute.toString();

        // 문제 1: writeMethodPrefix에 들어온 여러 접두어를 설정
        if (writeMethodPrefix != null) {
            for (String prefix : writeMethodPrefix) {
                log.debug("Write Method Prefix : {}", prefix);
                properties.setProperty(prefix + "*", writeOnlyTransactionAttributeDefinition);  // 각 접두어에 대해 쓰기 전용 트랜잭션 설정
            }
        }

        // 문제 2: writeMethodPrefix로 정의되지 않은 모든 메서드는 기본적으로 readOnly로 설정
        properties.setProperty("*", readOnlyTransactionAttributeDefinition);  // 기본적으로 모든 메서드는 읽기 전용 트랜잭션

        // 트랜잭션 속성 설정
        interceptor.setTransactionAttributes(properties);
        interceptor.setTransactionManager(transactionManager);
        return interceptor;
    }

    public Advisor txAdvisor(TransactionInterceptor txAdvice, String targetExpression) {
        AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
        pointcut.setExpression(targetExpression);
        return new DefaultPointcutAdvisor(pointcut, txAdvice);
    }

    public SqlSessionFactory getSqlSessionFactory(DataSource dataSource, ApplicationContext applicationContext, String typeAliasesPackage, String mapperLocation, String executeType) throws Exception {
        SqlSessionFactoryBean sessionFactoryBean = new SqlSessionFactoryBean();
        sessionFactoryBean.setDataSource(dataSource);
        sessionFactoryBean.setTypeAliasesPackage(typeAliasesPackage);
        sessionFactoryBean.setMapperLocations(applicationContext.getResources(mapperLocation));
        sessionFactoryBean.setVfs(SpringBootVFS.class);
        SqlSessionFactory factory = sessionFactoryBean.getObject();
        Configuration configuration = factory.getConfiguration();
        configuration.setMapUnderscoreToCamelCase(true);
        configuration.setCallSettersOnNulls(true);
        configuration.setJdbcTypeForNull(JdbcType.NULL);
        configuration.setCacheEnabled(false);
        if(executeType.equals("BATCH")) {
            configuration.setDefaultExecutorType(ExecutorType.BATCH);
        }else{
            configuration.setDefaultExecutorType(ExecutorType.REUSE);
        }
        log.debug("{} Execute Type : {}", prefix, executeType);
        return factory;
    }

    public CommonDAO getDAO(SqlSessionTemplate sqlSessionTemplate) {
        CommonDAO commonDAO = new CommonDAO();
        commonDAO.setSqlSessionTemplate(sqlSessionTemplate);
        return commonDAO;
    }


}
