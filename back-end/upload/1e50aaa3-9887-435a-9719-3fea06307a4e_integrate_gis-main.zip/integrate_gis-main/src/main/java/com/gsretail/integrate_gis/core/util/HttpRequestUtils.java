package com.gsretail.integrate_gis.core.util;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class HttpRequestUtils {
    public static String getHttpData(String url) throws RestClientException {
		return getHttpData(url, HttpMethod.GET, null, String.class);
	}

	public static String getHttpData(String url, Map<String, Object> params) throws RestClientException {
		return getHttpData(url, params, String.class);
	}

	public static <T> T getHttpData(String url, Class<T> responseType) throws RestClientException {
		return getHttpData(url, HttpMethod.GET, null, responseType);
	}

	public static <T> T getHttpData(String url, Map<String, Object> params, Class<T> responseType) throws RestClientException {
		return getHttpData(url, HttpMethod.GET, null, params, responseType);
	}

	public static <T> T getHttpData(String url, HttpMethod method, Map<String, Object> params, Class<T> responseType) throws RestClientException {
		return getHttpData(url, method, null, params, responseType);
	}

	public static <T> T getHttpData(String url, HttpMethod method, Map<String, String> headers, Map<String, Object> params, Class<T> responseType) throws RestClientException {
		return getHttpData(url, StandardCharsets.UTF_8, method, headers, params, responseType);
	}

	public static <T> T getHttpData(String url, Charset charset, HttpMethod method, Map<String, String> headers, Map<String, Object> params, Class<T> responseType) throws RestClientException {
		RestTemplate template = new RestTemplate();
		template.getMessageConverters().addFirst(new StringHttpMessageConverter(charset));

		StringBuilder builder = new StringBuilder();
		builder.append(url);

		if(params != null) {
			boolean isFirst = false;
			if(!url.contains("?")) {
				builder.append("?");
				isFirst = true;
			}

			for(Map.Entry<String, Object> entry : params.entrySet()) {
				if(isFirst) {
					isFirst = false;
				}else {
					builder.append("&");
				}

				builder.append(entry.getKey()).append("={").append(entry.getKey()).append("}");
			}
		}else {
			params = new HashMap<>();
		}

		HttpEntity<Map<String, String>> httpEntity = new HttpEntity<>(headers);

		ResponseEntity<T> response = template.exchange(builder.toString(), method, httpEntity, responseType, params);

		return response.getBody();
	}

}
