package com.gsretail.integrate_gis.core.request;

public enum ResultCode {
    ;

    /**
     * PUT의 key로 들어갈 값
     */
    public enum KEY {
        /**
         * 결과코드
         */
        RESULT("RESULT"),
        /**
         * 메시지
         */
        MESSAGE("MESSAGE"),
        /**
         * 데이터
         */
        DATA("DATA"),
        /**
         * 목록
         */
        LIST("LIST");

        private final String name;

        KEY(String name) {
            this.name = name;
        }

        /**
         * Key의 명칭
         *
         * @return the name
         */
        public String getName() {return name;}
    }

    /**
     * RESULT 항목에 들어갈 값
     */
    public enum RESULT {
        /**
         * 성공
         */
        SUCCESS("SUCCESS"),
        /**
         * 실패
         */
        FAILURE("FAILURE");

        private final String name;

        RESULT(String name) {
            this.name = name;
        }

        /**
         * Result의 명칭
         *
         * @return the name
         */
        public String getName() {return this.name;}
    }

}
