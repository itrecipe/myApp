package com.gsretail.integrate_gis.core.jwt.exception;

public enum AuthErrorStatus {
    ACCOUNT_EXPIRED,
    LOCKED,
    DISABLED,
    CREDENTIALS_EXPIRED,
    BAD_CREDENTIALS,
    ETC
}
