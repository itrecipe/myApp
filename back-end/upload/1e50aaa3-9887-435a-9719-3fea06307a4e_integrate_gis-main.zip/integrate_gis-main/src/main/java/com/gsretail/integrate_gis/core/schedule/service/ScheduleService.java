package com.gsretail.integrate_gis.core.schedule.service;


import com.gsretail.integrate_gis.core.schedule.manager.ScheduleContentManager;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ScheduledFuture;

@Component
@RequiredArgsConstructor
public class ScheduleService {

    private final ScheduleContentManager scheduleContentManager;

    private final TaskScheduler aldSTaskScheduler;

    private final Map<String, ScheduledFuture<?>> scheduledFutureMap = new HashMap<>();

    public void destorySchedule(String scheduleId, boolean mayInterruptIfRunning) {
        ScheduledFuture<?> schedule = scheduledFutureMap.get(scheduleId);
        if(schedule != null) {
            schedule.cancel(mayInterruptIfRunning);
            scheduledFutureMap.remove(scheduleId);
        }
    }

    public void setRunAtFixedRate(String scheduleId, String scheduleName, Duration duration, Object... args) {
        scheduledFutureMap.put(scheduleId, aldSTaskScheduler.scheduleAtFixedRate(() -> {
            try {
                Object bean = scheduleContentManager.getBean(scheduleName);
                Method method = scheduleContentManager.getMethod(scheduleName);
                method.invoke(bean, args);
            } catch (IllegalAccessException | InvocationTargetException e) {
                throw new RuntimeException(e);
            }
        }, duration));
    }

    public void setRunWithFixedDelay(String scheduleId, String scheduleName, Duration duration, Object... args) {
        scheduledFutureMap.put(scheduleId, aldSTaskScheduler.scheduleWithFixedDelay(() -> {
            try {
                Object bean = scheduleContentManager.getBean(scheduleName);
                Method method = scheduleContentManager.getMethod(scheduleName);
                method.invoke(bean, args);
            } catch (IllegalAccessException | InvocationTargetException e) {
                throw new RuntimeException(e);
            }
        }, duration));
    }

    public void setRunCronTrigger(String scheduleId, String scheduleName, String cronExpression, Object... args) {
        scheduledFutureMap.put(scheduleId, aldSTaskScheduler.schedule(() -> {
            try {
                Object bean = scheduleContentManager.getBean(scheduleName);
                Method method = scheduleContentManager.getMethod(scheduleName);
                method.invoke(bean, args);
            } catch (IllegalAccessException | InvocationTargetException e) {
                throw new RuntimeException(e);
            }
        }, new CronTrigger(cronExpression)));
    }

    public LocalDateTime getNextExecutionTime(String cronExpression) {
        return getNextExecutionTime(cronExpression, null);
    }

    public LocalDateTime getNextExecutionTime(String cronExpression, ZoneId zoneId) {
        CronTrigger cronTrigger = new CronTrigger(cronExpression);

        TriggerContext triggerContext = new TriggerContext() {
            @Override
            public Instant lastScheduledExecution() {
                return null;
            }

            @Override
            public Instant lastActualExecution() {
                return null;
            }

            @Override
            public Instant lastCompletion() {
                return null;
            }
        };
        Instant nextExecution = cronTrigger.nextExecution(triggerContext);

        if(zoneId == null) zoneId = ZoneId.systemDefault();

        return LocalDateTime.ofInstant(Objects.requireNonNull(nextExecution), zoneId);
    }

}
