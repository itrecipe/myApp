package com.gsretail.integrate_gis.core.schedule.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

@Slf4j
@Configuration
public class ScheduleConfig implements SchedulingConfigurer {

    @Value("${spring.schedule.executor.max-pool-size:20}")
    private int maxPoolSize;

    @Value("${spring.schedule.executor.thread-name-prefix:ALD-Schedule}")
    private String threadNamePrefix;


    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        log.debug("configureTasks Setting");
        taskRegistrar.setTaskScheduler(this.aldTaskScheduler());
    }


    @Bean(name = "aldSTaskScheduler")
    public TaskScheduler aldTaskScheduler() {
        log.debug("AldTaskScheduler Setting");
        ThreadPoolTaskScheduler taskScheduler = new ThreadPoolTaskScheduler();
        taskScheduler.setPoolSize(maxPoolSize);
        taskScheduler.setThreadNamePrefix(threadNamePrefix);
        taskScheduler.initialize();
        return taskScheduler;
    }

}
