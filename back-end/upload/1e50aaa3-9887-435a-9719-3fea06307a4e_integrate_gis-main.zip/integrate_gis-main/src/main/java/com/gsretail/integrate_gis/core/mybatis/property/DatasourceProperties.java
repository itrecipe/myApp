package com.gsretail.integrate_gis.core.mybatis.property;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@ToString
public class DatasourceProperties {
    private String className;
	private String jdbcUrl;
	private String username;
	private String password;
	private Integer maxPoolSize = 10;
	private Integer minIdle = 1;
	private String validationQuery;
	private Integer validationTimeout = 1000;
	private Integer connectionTimeout = 60000;
	private List<String> writeMethodPrefix = new ArrayList<>();
	private String targetExpression;
	private String defaultTypeAliasesPackage;
	private String defaultMapperLocations;
	private String batchTypeAliasesPackage;
	private String batchMapperLocations;
	private String executeType = "REUSE";

	public String[] getWriteMethodPrefixToArray() {
		String[] output = new String[writeMethodPrefix.size()];
		writeMethodPrefix.toArray(output);
		return output;
	}

}
