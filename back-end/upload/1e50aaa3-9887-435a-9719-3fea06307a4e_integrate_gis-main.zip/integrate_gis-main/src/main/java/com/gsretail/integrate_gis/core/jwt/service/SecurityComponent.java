package com.gsretail.integrate_gis.core.jwt.service;

import com.gsretail.integrate_gis.core.jwt.config.JwtTokenProvider;
import com.gsretail.integrate_gis.core.jwt.dto.JwtToken;
import com.gsretail.integrate_gis.core.jwt.exception.AuthErrorStatus;
import com.gsretail.integrate_gis.core.jwt.exception.AuthenticationException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

@Slf4j
@RequiredArgsConstructor
@Component
public class SecurityComponent {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;

    public JwtToken signIn(String username, String password) throws AuthenticationException {
        UsernamePasswordAuthenticationToken authenticationToken =  new UsernamePasswordAuthenticationToken(username, password);
        try{
            Authentication authentication = authenticationManager.authenticate(authenticationToken);
            return jwtTokenProvider.generateToken(authentication);
        }catch(AccountExpiredException e) {
            throw new AuthenticationException(AuthErrorStatus.ACCOUNT_EXPIRED, e);
        }catch(LockedException e) {
            throw new AuthenticationException(AuthErrorStatus.LOCKED, e);
        }catch(DisabledException e) {
            throw new AuthenticationException(AuthErrorStatus.DISABLED, e);
        }catch(CredentialsExpiredException e) {
            throw new AuthenticationException(AuthErrorStatus.CREDENTIALS_EXPIRED, e);
        }catch(BadCredentialsException e) {
            throw new AuthenticationException(AuthErrorStatus.BAD_CREDENTIALS, e);
        }catch(Exception e) {
            throw new AuthenticationException(AuthErrorStatus.ETC, e);
        }
    }

    public String resolveToken(HttpServletRequest request) {
        return jwtTokenProvider.resolveToken(request);
    }


    public String resolveCookieToken(HttpServletRequest request) {return jwtTokenProvider.resolveCookieToken(request);}


    public Authentication getAuthentication(String accessToken) {
        return jwtTokenProvider.getAuthentication(accessToken);
    }

    public JwtToken generateToken(Authentication authentication) {
        return jwtTokenProvider.generateToken(authentication);
    }

    public Boolean validateToken(String token) {
        return jwtTokenProvider.validateToken(token);
    }

}
