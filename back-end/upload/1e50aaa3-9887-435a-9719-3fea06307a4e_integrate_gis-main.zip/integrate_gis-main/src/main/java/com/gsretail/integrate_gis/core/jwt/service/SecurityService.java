package com.gsretail.integrate_gis.core.jwt.service;

import com.gsretail.integrate_gis.core.jwt.entity.AuthorityUrlEntity;
import com.gsretail.integrate_gis.core.jwt.entity.UserEntity;

import java.sql.SQLException;
import java.util.List;

public interface SecurityService {
    List<AuthorityUrlEntity> selectListAuthorityUrl() throws SQLException;
    UserEntity selectUserByUsername(String username) throws SQLException;
    List<String> selectRolesByUsername(String username) throws SQLException;
    String selectAccessToken(String username);
    String selectRefreshToken(String username);
}
