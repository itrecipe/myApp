package com.gsretail.integrate_gis.core.jwt.config;

import com.gsretail.integrate_gis.app.auth.service.AuthService;
import com.gsretail.integrate_gis.core.jwt.entity.AuthorityUrlEntity;
import com.gsretail.integrate_gis.core.jwt.service.SecurityService;
import com.gsretail.integrate_gis.core.util.CookieUtils;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import jakarta.annotation.Nonnull;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@RequiredArgsConstructor
@Slf4j
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtTokenProvider jwtTokenProvider;

    private final SecurityService securityService;

    private final AntPathMatcher pathMatcher = new AntPathMatcher();

    private final Long refreshValidSeconds;


    @Override
    protected void doFilterInternal(
            @Nonnull HttpServletRequest request,
            @Nonnull HttpServletResponse response,
            @Nonnull FilterChain filterChain) throws ServletException, IOException {
        String token = resolveCookieToken(request);

        try{
            List<AuthorityUrlEntity> checkAuthUrlList = securityService.selectListAuthorityUrl();

            boolean isCheck = false;

            String requestUri = request.getRequestURI();

            for(AuthorityUrlEntity authUrl : checkAuthUrlList){
                if(pathMatcher.match(authUrl.getTargetUrl(), requestUri)) {
                    if(!authUrl.getIsPermitAll()) {
                        log.debug("{} : {} : {}", authUrl.getTargetUrl(), requestUri, authUrl.toString());
                        isCheck = true;
                    }
                    break;
                }
            }

            if(isCheck && StringUtils.hasText(token) && jwtTokenProvider.validateToken(token)) {
                Claims claims = jwtTokenProvider.getClaims(token);

                String username = claims.getSubject();
                String checkToken = securityService.selectAccessToken(username);

                if(StringUtils.hasText(checkToken) && checkToken.equals(token)) {
                    Authentication auth = jwtTokenProvider.getAuthentication(token);
                    SecurityContextHolder.getContext().setAuthentication(auth);
                }
            }
        }catch(ExpiredJwtException e) {
            String requestBy = request.getHeader("X-Requested-By");
            if(requestBy != null && requestBy.equals("Frontend")) {
                response.setStatus(401);
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");

                String json = String.format("{\"error\": \"%s\", \"status\": %d}", "Expired JWT token", 401);
                response.getWriter().write(json);
                log.error("Expired JWT token", e);
                return;
            }else{
                String accessToken = jwtTokenProvider.refresh(request);
                log.debug("Access Token Refresh : {} : {}", token, accessToken);
                CookieUtils.setAccessTokenByResponseCookie(response, accessToken, refreshValidSeconds / 1000);
                Authentication auth = jwtTokenProvider.getAuthentication(accessToken);
                SecurityContextHolder.getContext().setAuthentication(auth);
            }
        }catch(SQLException e) {
            log.error(e.getMessage(), e);
        }

        filterChain.doFilter(request, response);
    }

    private String resolveToken(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if(StringUtils.hasText(bearerToken) && bearerToken.startsWith(jwtTokenProvider.getGrantType())) {
            return bearerToken.substring(jwtTokenProvider.getGrantType().length() + 1);
        }
        return null;
    }

    public String resolveCookieToken(HttpServletRequest request) {
        return jwtTokenProvider.resolveCookieToken(request);
    }

}
