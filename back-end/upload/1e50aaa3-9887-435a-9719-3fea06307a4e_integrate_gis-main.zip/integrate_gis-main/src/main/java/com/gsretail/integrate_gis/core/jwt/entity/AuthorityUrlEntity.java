package com.gsretail.integrate_gis.core.jwt.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@RequiredArgsConstructor
public class AuthorityUrlEntity {
    private Integer authUrlIdx;
    private final String targetUrl;
    private final String authName;
    private final Boolean isPermitAll;
    private Integer orderBy;
}
