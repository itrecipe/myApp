package com.gsretail.integrate_gis.core.jwt.config;

import com.gsretail.integrate_gis.app.auth.service.AuthService;
import com.gsretail.integrate_gis.core.jwt.custom.CustomUserDetailsService;
import com.gsretail.integrate_gis.core.jwt.entity.AuthorityUrlEntity;
import com.gsretail.integrate_gis.core.jwt.service.SecurityService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtTokenProvider jwtTokenProvider;

    private final PasswordEncoder passwordEncoder;

    private final SecurityService securityService;

    @Value("${jwt.refresh-token-valid-seconds}")
    private Long refreshValidSeconds;

    @Bean
    public UserDetailsService customUserDetailsService() {
        return new CustomUserDetailsService(securityService);
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.httpBasic(AbstractHttpConfigurer::disable)
                .csrf(AbstractHttpConfigurer::disable)
                .sessionManagement(sessionManageConfig -> sessionManageConfig.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(requestMatcher -> {
                    try {
                        List<AuthorityUrlEntity> authList = securityService.selectListAuthorityUrl();
                        List<String> roles = new ArrayList<>();
                        for(int i=0,cnt=authList.size(); i<cnt; i++){
                            AuthorityUrlEntity auth = authList.get(i);
                            String urlPath = auth.getTargetUrl();
                            String authName = auth.getAuthName();
                            boolean isPermitAll = auth.getIsPermitAll();

                            if(authName != null && !authName.isEmpty()){
                                roles.add(authName);
                            }

                            if(i != (cnt-1) && urlPath.equals((authList.get(i+1).getTargetUrl()))) {
                                continue;
                            }
                            if(isPermitAll){
                                requestMatcher.requestMatchers(urlPath).permitAll();
                                log.debug("Permit All Security Setting({})", urlPath);
                                roles.clear();
                                continue;
                            }

                            if(!roles.isEmpty()) {
                                requestMatcher.requestMatchers(urlPath).hasAnyRole(roles.toArray(String[]::new));
                                log.debug("Security Setting({}) : {}", urlPath, roles);
                                roles.clear();
                            }

                        }

                        requestMatcher.anyRequest().authenticated();
                    } catch (SQLException e) {
                        log.error("URL Path 권한조회 오류", e);
                    }
                })
                .sessionManagement(sessionManagement -> sessionManagement.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .addFilterBefore(new JwtAuthenticationFilter(jwtTokenProvider, securityService, refreshValidSeconds), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(UserDetailsService customUserDetailsService) {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(customUserDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder);
        return new ProviderManager(authProvider);
    }


}
