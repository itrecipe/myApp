package com.gsretail.integrate_gis.core.schedule.manager;

import com.gsretail.integrate_gis.core.schedule.annotation.AladdinScheduleMethod;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Component;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.ServiceConfigurationError;
import java.util.concurrent.ScheduledExecutorService;

@Slf4j
@Component
@RequiredArgsConstructor
public class ScheduleContentManager implements BeanPostProcessor {

    private final Map<String, Map<String, Object>> serviceList = new HashMap<>();


    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		if (bean instanceof AopInfrastructureBean || bean instanceof TaskScheduler ||
				bean instanceof ScheduledExecutorService) {
			return bean;
		}

        Class<?> clsType = bean.getClass();

        Method[] methods = bean.getClass().getDeclaredMethods();  // getMethods() -> getDeclaredMethods()

        for (Method method : methods) {
            AladdinScheduleMethod annotation = AnnotationUtils.findAnnotation(method, AladdinScheduleMethod.class);
            if (annotation != null) {
                log.debug("Found method: {} in bean: {}", method.getName(), beanName);
                String name = annotation.name();
                if(name.isEmpty()) {
                    name = beanName + "."+method.getName();
                }
                // 추가 로직이 필요하다면 여기에 추가
                if(serviceList.containsKey(name)) {
                    throw new ServiceConfigurationError("Already Content Init Error : " + name);
                }

                Map<String, Object> data = new HashMap<>();
                data.put("ClassType", clsType);
                data.put("bean", bean);
                data.put("method", method);
                serviceList.put(name, data);
            }
        }

		return bean;
    }

    public Object getBean(String name) {
        return this.serviceList.get(name).get("bean");
    }

    public Method getMethod(String name) {
        return (Method) this.serviceList.get(name).get("method");
    }

}

