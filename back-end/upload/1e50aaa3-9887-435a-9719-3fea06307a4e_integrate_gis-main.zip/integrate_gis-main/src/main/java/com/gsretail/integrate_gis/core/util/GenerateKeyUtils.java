package com.gsretail.integrate_gis.core.util;

import org.apache.commons.lang3.RandomStringUtils;

import java.time.LocalDateTime;
import java.time.ZoneId;

public class GenerateKeyUtils {

    private GenerateKeyUtils() {}

    /**
     * 13자리 이상의 Key를 생성하는 메서드
     *
     * @param length Key의 길이
     * @return the Unique(일시 + 랜덤키)한 키 생성
     */
    public static String generatorKeyLength(Integer length) {
        if(length - 13 < 0) throw new IndexOutOfBoundsException("최소 13자리 이상으로 해야합니다.");
        LocalDateTime dateTime = LocalDateTime.now();
        return String.format("%013x%s", dateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),
                RandomStringUtils.randomAlphanumeric(length - 13));
    }

}
