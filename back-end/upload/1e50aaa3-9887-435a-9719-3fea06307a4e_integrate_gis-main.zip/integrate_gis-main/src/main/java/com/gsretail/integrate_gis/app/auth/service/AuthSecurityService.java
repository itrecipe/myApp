package com.gsretail.integrate_gis.app.auth.service;


import com.gsretail.integrate_gis.core.jwt.entity.AuthorityUrlEntity;
import com.gsretail.integrate_gis.core.jwt.entity.UserEntity;
import com.gsretail.integrate_gis.core.jwt.service.HashOperationsService;
import com.gsretail.integrate_gis.core.jwt.service.SecurityService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Service
public class AuthSecurityService implements SecurityService {

    private final PasswordEncoder passwordEncoder;

    private final HashOperationsService hashOperationsService;

    @Value("${jwt.redis-refresh-token-key}")
    private String refreshKey;

    @Value("${jwt.redis-access-token-key}")
    private String accessKey;

    @Override
    public List<AuthorityUrlEntity> selectListAuthorityUrl() throws SQLException {
        List<AuthorityUrlEntity> listAuthorityUrl = new ArrayList<AuthorityUrlEntity>();
        //manifest.json
        listAuthorityUrl.add(new AuthorityUrlEntity("/manifest.json", null, true));
        listAuthorityUrl.add(new AuthorityUrlEntity("/favicon.ico", null, true));
        listAuthorityUrl.add(new AuthorityUrlEntity("/static/**", null, true));
        listAuthorityUrl.add(new AuthorityUrlEntity("/*.png", null, true));
        listAuthorityUrl.add(new AuthorityUrlEntity("/js/**", null, true));
        listAuthorityUrl.add(new AuthorityUrlEntity("/css/**", null, true));
        listAuthorityUrl.add(new AuthorityUrlEntity("/api/sample/sampleImage", null, true));
        /*listAuthorityUrl.add(new AuthorityUrlEntity("/api/**", null, true));*/
        listAuthorityUrl.add(new AuthorityUrlEntity("/error", null, true));
        listAuthorityUrl.add(new AuthorityUrlEntity("/auth/**", null, true));
        listAuthorityUrl.add(new AuthorityUrlEntity("/", null, true));
        /*listAuthorityUrl.add(new AuthorityUrlEntity("/map", null, true));*/
        listAuthorityUrl.add(new AuthorityUrlEntity("/**", "ADMIN", false));
        return listAuthorityUrl;
    }

    @Override
    public UserEntity selectUserByUsername(String s) throws SQLException {
        UserEntity userEntity = new UserEntity();
        userEntity.setUsername(s);
        userEntity.setPassword(passwordEncoder.encode("test00!"));
        userEntity.setAccountNonExpired(true);
        userEntity.setAccountNonLocked(true);
        userEntity.setCredentialsNonExpired(true);
        userEntity.setEnabled(true);
        return userEntity;
    }

    @Override
    public List<String> selectRolesByUsername(String s) throws SQLException {
        List<String> list = new ArrayList<>();
        list.add("ADMIN");
        list.add("USER");
        return list;
    }

    @Override
    public String selectAccessToken(String username) {
        return (String) hashOperationsService.get(accessKey, username);
    }

    @Override
    public String selectRefreshToken(String username) {
        return (String) hashOperationsService.get(refreshKey, username);
    }

}
