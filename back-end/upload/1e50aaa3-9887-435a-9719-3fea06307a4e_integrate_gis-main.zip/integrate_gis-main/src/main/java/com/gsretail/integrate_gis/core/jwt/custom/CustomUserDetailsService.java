package com.gsretail.integrate_gis.core.jwt.custom;

import com.gsretail.integrate_gis.core.jwt.entity.UserEntity;
import com.gsretail.integrate_gis.core.jwt.service.SecurityService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.sql.SQLException;

@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final SecurityService securityService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        try {
            UserEntity entity = securityService.selectUserByUsername(username);
            entity.setAuthorities(securityService.selectRolesByUsername(username));
            return entity;
        } catch (SQLException | NullPointerException e) {
            throw new UsernameNotFoundException("사용자를 찾을수 없습니다.", e);
        }
    }

}
