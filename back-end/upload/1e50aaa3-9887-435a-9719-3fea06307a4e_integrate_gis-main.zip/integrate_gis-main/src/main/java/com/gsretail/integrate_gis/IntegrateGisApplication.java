package com.gsretail.integrate_gis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegrateGisApplication {

    public static void main(String[] args) {
        SpringApplication.run(IntegrateGisApplication.class, args);
    }

}
