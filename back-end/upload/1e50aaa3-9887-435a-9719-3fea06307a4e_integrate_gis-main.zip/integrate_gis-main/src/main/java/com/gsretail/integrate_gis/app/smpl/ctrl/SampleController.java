package com.gsretail.integrate_gis.app.smpl.ctrl;

import com.gsretail.integrate_gis.app.smpl.service.VworldService;
import com.gsretail.integrate_gis.core.request.ResultMap;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/sample")
@RequiredArgsConstructor
public class SampleController {

    private final VworldService vworldService;

	@GetMapping(value = "/test")
	public ResultMap hello(
			Integer test,
			String test2
	) {
		ResultMap result = new ResultMap();
		try{
			Map<String, Object> data = new HashMap<String, Object>();
			data.put("text", "Hello World" + test + " : " + test2);
			data.put("text2", "테수투");

			result.setData(data);
			result.setSuccess();
		}catch(NullPointerException e) {
			if(log.isErrorEnabled()) {
				log.error("/api/test Error", e);
			}
		}

		return result;
	}

	@GetMapping(value = "/sampleImage")
	@ResponseBody
	public void sampleImage(HttpServletResponse response) {
		Resource resource = new ClassPathResource("/static/images/KMA.png");
		try(InputStream inputStream = resource.getInputStream()) {
			response.setContentType("image/png");
			IOUtils.copy(inputStream, response.getOutputStream());
		} catch(IOException e) {
			log.error("/api/sampleImage Error", e);
		}
	}

	@PostMapping(value="/vworldRoadAddressApi")
	public ResultMap vworldRoadAddressApi(
			String keyword,
			Integer pageSize,
			Integer page,
			String bbox,
			String crs) {
		ResultMap result = new ResultMap();
		try{
			Map<String, Object> data = vworldService.getAddressList(VworldService.ADDRESS_ROAD, keyword, pageSize, page, bbox, crs);

			result.setData(data);
			if("OK".equals(data.get("status"))) {
				result.setSuccess();
			}
		}catch(NullPointerException e) {
			if(log.isErrorEnabled()) {
				log.error("/api/sample/vworldRoadAddressApi.do Error", e);
			}
		}

		return result;
	}

	@PostMapping(value="/vworldParcelAddressApi")
	public ResultMap vworldParcelAddressApi(String keyword, Integer pageSize, Integer page, String bbox, String crs) {
		ResultMap result = new ResultMap();
		try{
			Map<String, Object> data = vworldService.getAddressList(VworldService.ADDRESS_PARCEL, keyword, pageSize, page, bbox, crs);

			result.setData(data);
			if("OK".equals(data.get("status"))) {
				result.setSuccess();
			}
		}catch(NullPointerException e) {
			if(log.isErrorEnabled()) {
				log.error("/api/sample/vworldParcelAddressApi.do Error", e);
			}
		}

		return result;
	}

	@PostMapping(value="/vworldPlaceAddressApi")
	public ResultMap vworldPlaceAddressApi(String keyword, Integer pageSize, Integer page, String bbox, String crs) {
		ResultMap result = new ResultMap();
		try{
			Map<String, Object> data = vworldService.getPlaceList(null, keyword, pageSize, page, bbox, crs);

			result.setData(data);
			if("OK".equals(data.get("status"))) {
				result.setSuccess();
			}
		}catch(NullPointerException e) {
			if(log.isErrorEnabled()) {
				log.error("/api/sample/vworldPlaceAddressApi.do Error", e);
			}
		}

		return result;
	}

}
