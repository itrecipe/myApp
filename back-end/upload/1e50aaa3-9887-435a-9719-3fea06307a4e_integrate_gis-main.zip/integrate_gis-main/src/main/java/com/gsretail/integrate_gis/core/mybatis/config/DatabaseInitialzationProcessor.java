package com.gsretail.integrate_gis.core.mybatis.config;

import com.gsretail.integrate_gis.core.mybatis.dao.CommonDAO;
import com.gsretail.integrate_gis.core.mybatis.property.DatasourceProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.aop.Advisor;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.env.PropertySource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.interceptor.TransactionInterceptor;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
@Slf4j
public class DatabaseInitialzationProcessor implements BeanFactoryPostProcessor, ApplicationContextAware {

    private ApplicationContext applicationContext;
    private String propertiesPrefix = "spring.database";

    private Map<String, DatasourceProperties> getPropertiesMap() {
        Map<String, DatasourceProperties> propertiesMap = new HashMap<String, DatasourceProperties>();
        Environment env = applicationContext.getEnvironment();
        if(env instanceof ConfigurableEnvironment) {
            for(PropertySource<?> propertySource : ((ConfigurableEnvironment) env).getPropertySources()) {
                if(propertySource instanceof EnumerablePropertySource) {
                    for(String key : ((EnumerablePropertySource<?>) propertySource).getPropertyNames()) {
                        if(key.startsWith(propertiesPrefix)) {
                            String key2 = key.replace(propertiesPrefix+".", "");
                            String datasourceType = key2.substring(0, key2.indexOf("."));

                            DatasourceProperties dsProperties = propertiesMap.get(datasourceType);
                            if(dsProperties == null) {
                                dsProperties = new DatasourceProperties();
                                propertiesMap.put(datasourceType, dsProperties);
                            }

                            String propertyName = key2.replace(datasourceType + ".datasource.", "");
                            Object value = propertySource.getProperty(key);
                            log.debug("Database Property({}) : {}", propertyName, value);
                            switch(propertyName) {
                                case "className" :
                                    dsProperties.setClassName(String.valueOf(value));
                                    break;
                                case "jdbcUrl" :
                                    dsProperties.setJdbcUrl((String) value);
                                    break;
                                case "username" :
                                    dsProperties.setUsername((String) value);
                                    break;
                                case "password" :
                                    dsProperties.setPassword((String) value);
                                    break;
                                case "maxPoolSize" :
                                    dsProperties.setMaxPoolSize((Integer) value);
                                    break;
                                case "minIdle" :
                                    dsProperties.setMinIdle((Integer) value);
                                    break;
                                case "validationQuery" :
                                    dsProperties.setValidationQuery((String) value);
                                    break;
                                case "validationTimeout" :
                                    dsProperties.setValidationTimeout((Integer) value);
                                    break;
                                case "connectionTimeout" :
                                    dsProperties.setConnectionTimeout((Integer) value);
                                    break;
                                case "targetExpression" :
                                    dsProperties.setTargetExpression((String) value);
                                    break;
                                case "default.typeAliasesPackage":
                                    dsProperties.setDefaultTypeAliasesPackage((String) value);
                                    break;
                                case "default.mapperLocations" :
                                    dsProperties.setDefaultMapperLocations((String) value);
                                    break;
                                case "executeType" :
                                    dsProperties.setExecuteType((String) value);
                                    break;
                                default :
                                    if(propertyName.startsWith("writeMethodPrefix")) {
                                        List<String> writeMethodPrefix = dsProperties.getWriteMethodPrefix();
                                        if(writeMethodPrefix == null) {
                                            writeMethodPrefix = new ArrayList<>();
                                            dsProperties.setWriteMethodPrefix(writeMethodPrefix);
                                        }
                                        writeMethodPrefix.add((String) value);
                                    }else{
                                        log.error("Not Found Property({}) : {}", key, propertySource.getProperty(key));
                                    }
                                    break;
                            }

                        }
                    }
                }
            }
        }
        return propertiesMap;
    }

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
        Map<String, DatasourceProperties> propertiesMap = getPropertiesMap();
        for(Map.Entry<String, DatasourceProperties> entry : propertiesMap.entrySet()) {
            log.debug("Database Property({}) : {}", entry.getKey(), entry.getValue().toString());

            try{
                DatasourceProperties dsProperties = entry.getValue();
                DatabaseConfig conf = new DatabaseConfig(
                        entry.getKey(),
                        dsProperties.getClassName(),
                        dsProperties.getJdbcUrl(),
                        dsProperties.getUsername(),
                        dsProperties.getPassword(),
                        dsProperties.getMaxPoolSize(),
                        dsProperties.getMinIdle(),
                        dsProperties.getValidationQuery(),
                        dsProperties.getValidationTimeout(),
                        dsProperties.getConnectionTimeout()
                );

                DataSource dataSource = conf.getDataSource();
                beanFactory.registerSingleton(entry.getKey() + "DataSource", dataSource);

                DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(dataSource);
                beanFactory.registerSingleton(entry.getKey() + "TransactionManager", transactionManager);

                TransactionInterceptor transactionInterceptor = conf.txInterceptor(transactionManager, dsProperties.getWriteMethodPrefixToArray());
                beanFactory.registerSingleton(entry.getKey() + "TransactionInterceptor", transactionInterceptor);

                Advisor advisor = conf.txAdvisor(transactionInterceptor, dsProperties.getTargetExpression());
                beanFactory.registerSingleton(entry.getKey() + "Advisor", advisor);

                SqlSessionFactory sqlSessionFactory = conf.getSqlSessionFactory(
                        dataSource,
                        applicationContext,
                        dsProperties.getDefaultTypeAliasesPackage(),
                        dsProperties.getDefaultMapperLocations(),
                        dsProperties.getExecuteType()
                );
                beanFactory.registerSingleton(entry.getKey() + "SqlSessionFactory", sqlSessionFactory);

                SqlSessionTemplate sqlSessionTemplate = new SqlSessionTemplate(sqlSessionFactory);
                beanFactory.registerSingleton(entry.getKey() + "SqlSessionTemplate", sqlSessionTemplate);

                log.debug("{} Execute Type : {}", propertiesPrefix, sqlSessionTemplate.getExecutorType());

                CommonDAO commonDAO = conf.getDAO(sqlSessionTemplate);
                beanFactory.registerSingleton(entry.getKey() + "CommonDAO", commonDAO);
            }catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

}
