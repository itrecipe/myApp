package com.gsretail.integrate_gis.core.jwt.exception;

import lombok.Getter;

@Getter
public class AuthenticationException extends RuntimeException {

    private final AuthErrorStatus status;

    public AuthenticationException(AuthErrorStatus status) {
        this.status = status;
    }

    public AuthenticationException(AuthErrorStatus status, Throwable cause) {
        super(cause);
        this.status = status;
    }

    public AuthenticationException(AuthErrorStatus status, Throwable cause, String message) {
        super(message, cause);
        this.status = status;
    }

}
