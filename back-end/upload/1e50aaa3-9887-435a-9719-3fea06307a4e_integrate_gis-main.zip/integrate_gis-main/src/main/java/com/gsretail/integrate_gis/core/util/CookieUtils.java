package com.gsretail.integrate_gis.core.util;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.ResponseCookie;

public class CookieUtils {


    public static void setAccessTokenByResponseCookie(HttpServletResponse response, String accessToken, Long timeout) {
            ResponseCookie cookie = ResponseCookie.from("accessToken", accessToken)
                    .httpOnly(true)
                    /*.secure(true)*/
                    .path("/")
                    .sameSite("Strict")
                    .maxAge(timeout)
                    .build();

            response.addHeader("Set-Cookie", cookie.toString());
    }

}
