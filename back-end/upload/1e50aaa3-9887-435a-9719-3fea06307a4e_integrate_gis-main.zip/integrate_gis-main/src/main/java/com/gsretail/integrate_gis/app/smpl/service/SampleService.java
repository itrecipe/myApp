package com.gsretail.integrate_gis.app.smpl.service;

import com.gsretail.integrate_gis.core.mybatis.dao.CommonDAO;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class SampleService {

    private final CommonDAO mainDAO;

    @PostConstruct
    public void init() throws SQLException {
        List<Map<String, Object>> list = mainDAO.selectList("SampleMapper.selectSample");

        for(Map<String, Object> map : list) {
            System.out.println(map);
        }
    }

}
