package com.gsretail.integrate_gis.core.jwt.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
@RequiredArgsConstructor
public class HashOperationsService {

    private final RedisTemplate<String, Object> redisTemplate;

    public void expire(String tableName, long timeout, TimeUnit unit) {
        redisTemplate.expire(tableName, timeout, unit);
    }

    public void put(String tableName, String key, Object value) {
        redisTemplate.opsForValue().set(String.format("%s_%s", tableName, key), value);
    }

    public void put(String tableName, String key, Object value, long timeout, TimeUnit unit) {
        redisTemplate.opsForValue().set(String.format("%s_%s", tableName, key), value, timeout, unit);
    }

    public Object get(String tableName, String key) {
        return redisTemplate.opsForValue().get(String.format("%s_%s", tableName, key));
    }

    public void delete(String tableName, String key) {
        redisTemplate.delete(String.format("%s_%s", tableName, key));
    }

    public void deleteAll() {
        Set<String> keys = redisTemplate.keys("*");
        if (keys != null && !keys.isEmpty()) {
            redisTemplate.delete(keys); // 모든 키 삭제
        }
    }

    public Long size(String tableName) {
        long cnt = 0;
        Set<String> keys = redisTemplate.keys(String.format("%s*", tableName));

        if(keys != null && !keys.isEmpty()) {
            cnt = keys.size();
        }

        return cnt;
    }

}
