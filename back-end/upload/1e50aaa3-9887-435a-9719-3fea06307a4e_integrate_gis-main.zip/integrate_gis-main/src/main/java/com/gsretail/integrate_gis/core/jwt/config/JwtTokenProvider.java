package com.gsretail.integrate_gis.core.jwt.config;

import com.gsretail.integrate_gis.core.jwt.dto.JwtToken;
import com.gsretail.integrate_gis.core.jwt.entity.UserEntity;
import com.gsretail.integrate_gis.core.jwt.service.HashOperationsService;
import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AccountExpiredException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.crypto.SecretKey;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Getter
@Service
public class JwtTokenProvider {

    private final SecretKey key;

    private final HashOperationsService hashOperationsService;

    @Value("${jwt.redis-refresh-token-key}")
    private String refreshKey;

    @Value("${jwt.redis-access-token-key}")
    private String accessKey;

    @Value("${jwt.access-token-valid-seconds:3600000}")
    private Integer accessTokenValiditySeconds;

    @Value("${jwt.refresh-token-valid-seconds:43200000}")
    private Integer refreshTokenValiditySeconds;

    @Value("${jwt.grant-type:Bearer}")
    private String grantType;

    public JwtTokenProvider(@Value("${jwt.secret}") String secretKey, HashOperationsService hashOperationsService) {
        System.out.println(secretKey);
        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        /*byte[] keyBytes = secretKey.getBytes(StandardCharsets.UTF_8);*/
        this.key = Keys.hmacShaKeyFor(keyBytes);
        this.hashOperationsService = hashOperationsService;
    }

    public String resolveToken(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if(StringUtils.hasText(bearerToken) && bearerToken.startsWith(this.getGrantType())) {
            return bearerToken.substring(this.getGrantType().length() + 1);
        }
        return null;
    }

    public String resolveCookieToken(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("accessToken".equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }

        return null;
    }

    public JwtToken generateToken(Authentication authentication) {
        String authorities = authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority).collect(Collectors.joining(","));

        long now = (new Date()).getTime();


        String accessToken = Jwts.builder().subject(authentication.getName())
                .claim("auth", authorities).expiration(new Date(now + accessTokenValiditySeconds))
                .signWith(key)
                .compact();

        String refreshToken = Jwts.builder().expiration(new Date(now + refreshTokenValiditySeconds))
                .signWith(key)
                .compact();

        return JwtToken.builder()
                .grantType(grantType)
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .build();
    }

    public Authentication getAuthentication(String token) {
        Claims claims = getClaims(token);

        if(claims.get("auth") == null) {
            throw new RuntimeException("권한 정보가 없는 토큰입니다.");
        }

        Collection<? extends GrantedAuthority> authorities = Arrays.stream(claims.get("auth").toString().split(","))
                .map(SimpleGrantedAuthority::new).toList();

        UserEntity user = new UserEntity();
        user.setUsername(claims.getSubject());
        user.setAuthorities(authorities);

        return new UsernamePasswordAuthenticationToken(user, "", authorities);
    }

    public boolean validateToken(String token) throws ExpiredJwtException {
        try{
            Jwts.parser().verifyWith(key).build().parseSignedClaims(token);
            return true;
        }catch(SecurityException | MalformedJwtException e){
            log.info("Invalid JWT token", e);
        }catch(UnsupportedJwtException e){
            log.info("Unsupported JWT token", e);
        }catch(IllegalArgumentException e){
            log.info("JWT claims string is empty", e);
        }
        return false;
    }

    public Claims getClaims(String token) {
        try {
            return Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload();
        }catch(ExpiredJwtException e) {
            return e.getClaims();
        }
    }


    public String refresh(HttpServletRequest request) throws NullPointerException {
        String newAccessToken = null;

        String accessToken = resolveCookieToken(request);

        Authentication authInfo = getAuthentication(accessToken);

        Object checkAccessToken = hashOperationsService.get(accessKey, authInfo.getName());
        Object refreshToken = hashOperationsService.get(refreshKey, authInfo.getName());

        log.debug("{} : {} : {} : {}", authInfo.getName(), accessToken, checkAccessToken, refreshToken);

        if(!io.micrometer.common.util.StringUtils.isEmpty((String) checkAccessToken) && !checkAccessToken.equals(accessToken)) {
            throw new AccountExpiredException(("다른 사람이 접근하였습니다."));
        }

        if(refreshToken == null) {
            throw new NullPointerException("토큰을 찾을 수 없습니다.");
        }

        if(!validateToken((String)refreshToken)) {
            throw new AccountExpiredException("토큰의 유효기간이 만료되었습니다.");
        }

        JwtToken newToken = generateToken(authInfo);
        if (newToken != null) {
            /*newAccessToken = newToken.getGrantType() + " " + newToken.getAccessToken();*/
            newAccessToken = newToken.getAccessToken();
            hashOperationsService.put(refreshKey, authInfo.getName(), newToken.getRefreshToken(), refreshTokenValiditySeconds, TimeUnit.SECONDS);
            hashOperationsService.put(accessKey, authInfo.getName(), newToken.getAccessToken(), accessTokenValiditySeconds, TimeUnit.SECONDS);
            log.debug((String) hashOperationsService.get(refreshKey, authInfo.getName()));
            log.debug("Refresh Token Size: {}", hashOperationsService.size(refreshKey));
        }
        return newAccessToken;
    }

}
