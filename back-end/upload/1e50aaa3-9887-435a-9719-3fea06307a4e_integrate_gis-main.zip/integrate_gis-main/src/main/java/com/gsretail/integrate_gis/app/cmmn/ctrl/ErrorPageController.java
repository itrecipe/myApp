package com.gsretail.integrate_gis.app.cmmn.ctrl;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;

@Slf4j
@Controller
public class ErrorPageController implements ErrorController {

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, HttpServletResponse response, Model model) throws IOException {

        Integer status = response.getStatus();

        String requestBy = request.getHeader("X-Requested-By");
        if(requestBy != null && requestBy.equals("Frontend")) {
            return null;
        }

        // 상태 코드에 따라 다른 페이지로 리디렉션 가능
        if (status == 404) {
            return "redirect:/error?code=404";
        } else if (status == 500) {
            return "redirect:/error?code=500";
        } else if( status == 403) {
            return "redirect:/error?code=403";
        }

        return "index";

    }
}
