package com.gsretail.integrate_gis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegrateGisApplicationTests {

    @Test
    void contextLoads() {
    }

}
