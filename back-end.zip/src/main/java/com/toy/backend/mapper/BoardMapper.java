package com.toy.backend.mapper;

import com.toy.backend.domain.Boards;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper extends BaseMapper<Boards> {

}
